package com.qprogramming.bookgeneration

import android.content.pm.ActivityInfo
import android.os.Bundle
import android.util.Log
import android.view.KeyEvent
import android.view.View
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.VolleyError
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.util.*


class RegistrationActivity : AppCompatActivity() {

    var json : String = " "
    var jObj: JSONObject? = null

    var listViewCountries : ListView? = null
    var listViewCodesPhone : ListView? = null

    var arrayCountries: ArrayList<String> = arrayListOf()
    var arrayCodes: ArrayList<String> = arrayListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registration)
        setSupportActionBar(findViewById(R.id.toolbar))

        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        setTitle(R.string.registration)

        listViewCountries = findViewById<ListView>(R.id.listView_Country)
        listViewCodesPhone  = findViewById<ListView>(R.id.listView_CodePhone)

        requestAboutCountryCodePhone()

//        TODO   Commented code that send e-mail
//        findViewById<FloatingActionButton>(R.id.fab).setOnClickListener { view ->
//            Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                    .setAction("Action", null).show()
//        }
    }
    //_________________________________________________________________________

    fun requestAboutCountryCodePhone() {
        var strResponce = ""
        var isError = false
        var volleyError: VolleyError? = null
        var strUrl  = AppEnv.url + "/Getcountries/1"
        var value_status_user = 0

        // Instantiate the RequestQueue.
        val queue: RequestQueue =  Volley.newRequestQueue(baseContext) // getApplicationContext());

        // Request a string response from the provided URL.
        val stringRequest = StringRequest(
            Request.Method.GET,
            strUrl,
            { response: String -> // Display the first 500 characters of the response string.
                strResponce = response

                try {
                    json = strResponce
                } catch (e: Exception) {
                    Log.e("Buffer Error", "Error converting result " + e.toString());
                }
                try {
                    jObj = JSONObject(json);

                    unPackAndShowCountriesAndCodePhoneFromServer(jObj!!)
                } catch (e: JSONException) {
                    Log.e("JSON Parser For Parser", "Error parsing data " + e.toString());
                }
            },
            { error -> //textView.setText("That didn't work!");
                volleyError = error
                isError = true
            }
        )

        // Add the request to the RequestQueue.
        queue.add(stringRequest)
    }
    //_________________________________________________________________________

    fun unPackAndShowCountriesAndCodePhoneFromServer(jsonObj: JSONObject){
        try {
            var inputArray = jsonObj!!.getJSONArray("GetCountriesResult")

            var arrayCountriesCodes: ArrayList<String>? = arrayListOf()

            var lenCountriesCodes: Int = inputArray.length()
            for (i in 0 until lenCountriesCodes) {
                var objectsCountriesCodes : String = inputArray.getString(i)
                arrayCountriesCodes!!.add(objectsCountriesCodes)

                var objectCountryCodes : JSONObject? = null
                objectCountryCodes = JSONObject(objectsCountriesCodes)

                var country : String = objectCountryCodes.getString("Name") //.getString("Name")
                arrayCountries!!.add(country)

                var jsonArrayCodesPhone : JSONArray? = objectCountryCodes.getJSONArray("Codes")
                var lenCodes: Int = jsonArrayCodesPhone!!.length()
                for (j in 0 until lenCodes) {
                    //var strCode= jsonArrayCodesPhone.getString(j)
                    var jsonCode = JSONObject(jsonArrayCodesPhone.getString(j))
                    arrayCodes.add(jsonCode.getString("Code"))
                }
            }

        }
        catch (e: JSONException)
        {
            Log.d("Error unpackCountr", e.toString())
        }

        // Create adapters
        val adapterCountries: ArrayAdapter<String>
        adapterCountries = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, arrayCountries)
        listViewCountries!!.setAdapter(adapterCountries)

        val adapterCodes: ArrayAdapter<String>
        adapterCodes = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, arrayCodes)
        listViewCodesPhone!!.setAdapter(adapterCodes)
    }
    //_________________________________________________________________________
}