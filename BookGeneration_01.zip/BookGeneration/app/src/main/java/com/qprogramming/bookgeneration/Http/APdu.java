package com.qprogramming.bookgeneration.Http;

import com.qprogramming.bookgeneration.Entities.Response;

public class APdu {

    public enum APDU_TYPE { REQUEST, RESPONSE, EVENT }
    public enum APDU_CMD  { UNKNOWN, ALIVE, get_record_id, get_workplans, get_workplan, add_workplan,
        get_tip, get_goal, add_client, get_message, get_my_progress, get_gym_info,
        send_exercise_rating, send_workplan_rating, update_exercise,refresh_image,
        send_complient, send_feedback, chat, get_chat_message, open_chat,
        CHANE_COLLECTION_TIME, CHANE_DELIVERY_TIME, UI_PAYMENT_DETAILS, get_laundries,
        refresh_order_screen, upgrade_app_version, request_message, order_approved}

    public enum APDU_RESULT { NONE, SUCCESS, UNSUCCESS }


    public APdu (APDU_TYPE type, APDU_CMD cmd, String[] params, APDU_RESULT result) {
        _type = type;
        _cmd = cmd;
        _params = params;
        _result = result;
    }

    public APdu (APDU_TYPE type, APDU_CMD cmd, String[] params) {
        this (type, cmd, params, APDU_RESULT.NONE, null);
    }

    public APdu (APDU_TYPE type, APDU_CMD cmd, String[] params, APDU_RESULT result, Response response) {
        _type = type;
        _cmd = cmd;
        _params = params;
        _result = result;
        _response = response;
    }

    public String toString () {
        String rc = "type=[" + _type.name () + "] cmd=[" + _cmd.name () + "] result=[" + _result.name () + "]";
        if (_params != null) {
            for (int i=0; i<_params.length; i++) {
                rc += " param" + (i+1) + "=[" + _params[i] + "]";
            }
        }
        return rc;
    }

    public APDU_TYPE type () 	{ return _type; }
    public APDU_CMD cmd () 		{ return _cmd; }
    public String[] params () { return _params; }
    public APDU_RESULT result () 	{ return _result; }
    public Response response() { return _response;}

    private String[] 	_params = null;
    private APDU_RESULT _result 	= null;
    private APDU_TYPE _type 	= null;
    private APDU_CMD 	_cmd 		= null;
    private Response _response = null;
}

