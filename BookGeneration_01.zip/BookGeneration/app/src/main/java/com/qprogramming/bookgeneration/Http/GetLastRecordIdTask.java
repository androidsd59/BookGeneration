package com.qprogramming.bookgeneration.Http;

import android.os.AsyncTask;
import android.util.Log;

import com.qprogramming.bookgeneration.AppEnv;
import com.qprogramming.bookgeneration.Managers.ClientManager;

import org.json.JSONException;
import org.json.JSONObject;

//  TODO  create package   com.qprogramming.smarttrainer
//import com.qprogramming.smarttrainer.AppEnv;
//import com.qprogramming.smarttrainer.MainActivity;
//import com.qprogramming.smarttrainer.Managers.ClientManager;

public class GetLastRecordIdTask extends AsyncTask<Void, Void, Integer> {
    protected Integer doInBackground(Void... params) {
        int record_id = 0;
        try {
            JSONParser jParser = new JSONParser();

            // getting JSON string from URL
            JSONObject json = jParser.getJSONFromUrl(AppEnv.url + "/getuser/123");

            try {
                if(json != null)
                {
                    record_id = json.getInt("GetRecordIdResult");
                }
            }
            catch (JSONException e) {
                Log.e ("GetLastRecordId. Error ", e.getMessage (), e);
            }
            return record_id;
        } catch (Exception e) {
            return record_id;
        }
    }

    @Override
    protected void onPostExecute(Integer record_id) {
        record_id = 1;
        ClientManager client_manager = new ClientManager();
        client_manager.update_record_id(record_id);
        AppEnv.Personal.setRecordId(record_id);

//  TODO  uncomment oparetor
//        MainActivity.httpUtils.NotifyObservers(APdu.APDU_CMD.get_record_id.toString(), record_id);
    }


}
