package com.qprogramming.bookgeneration.Entities;
public class Response {

    String dest;
    String req;
    String command;
    Object data;

    public void setDest(String dest) {
        this.dest = dest;
    }

    public String getDest() {
        return this.dest;
    }

    public void setReq(String req) {
        this.req = req;
    }

    public String getReq() {
        return this.req;
    }

    public void setCommand(String command) {
        this.command = command;
    }

    public String getcommand() {
        return this.command;
    }

    public Object getData()
    {
        return data;
    }
    public void setData(Object data)
    {
        this.data = data;
    }
}
