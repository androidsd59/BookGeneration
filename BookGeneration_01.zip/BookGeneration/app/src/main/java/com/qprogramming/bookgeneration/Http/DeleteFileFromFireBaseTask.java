package com.qprogramming.bookgeneration.Http;

import android.os.AsyncTask;
import android.os.FileUtils;

//import com.qprogramming.smarttrainer.SplashActivity;
//import com.qprogramming.smarttrainer.Util.uploadfiles.FileUtils;

import java.io.FileNotFoundException;

public class DeleteFileFromFireBaseTask extends AsyncTask<String, Void, Boolean> {

    protected Boolean doInBackground(String... params) {
        String fileKey = params[0];
        String type = params[1];

        //  TODO  uncomment this operator
        //        FileUtils.deleteFile(Integer.parseInt(type), fileKey);

        return true;
    }

    @Override
    protected void onPostExecute(Boolean result) {
    }
}
