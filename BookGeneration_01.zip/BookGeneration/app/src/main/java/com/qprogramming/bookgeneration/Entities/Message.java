package com.qprogramming.bookgeneration.Entities;

public class Message {
    int record_id = 0;
    String command;
    String data;

    public int getRecordId()
    {
        return record_id;
    }
    public void setRecordId(int record_id)
    {
        this.record_id= record_id ;
    }

    public String getCommand()
    {
        return command;
    }
    public void setCommand(String command)
    {
        this.command= command ;
    }

    public String getData()
    {
        return data;
    }
    public void setData(String data)
    {
        this.data = data ;
    }
}
