package com.qprogramming.bookgeneration.Http;

import android.util.Log;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;

//===============================================
/*
import org.apache.commons.io.IOUtils;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
*/
//===============================================
//import org.apache.http.impl.client.HttpClientBuilder;

public class JSONParser {

    static InputStream is = null;
    static JSONObject jObj = null;
    static String json = "";

//    static String strResponce = "";
//    static Boolean isError = false;
//    static VolleyError volleyError = null;
//    static String   strUrl = "";

    // constructor
    public JSONParser() {

    }

    public JSONObject getJSONFromUrl(String url) {

        //strUrl = url;

        // Making HTTP request
        try {
            // defaultHttpClient
            DefaultHttpClient httpClient = new DefaultHttpClient();
            //CloseableHttpClient httpClient = new HttpClientBuilder().create().build();
            HttpGet httpget = new HttpGet(url);

            HttpResponse httpResponse = httpClient.execute(httpget);
            HttpEntity httpEntity = httpResponse.getEntity();
            is = httpEntity.getContent();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (ClientProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(is, "utf-8"), 8);
            StringBuilder sb = new StringBuilder();
            String line = null;
            while ((line = reader.readLine()) != null) {
                sb.append(line + "\n");
            }
            is.close();
            json = sb.toString();//here json type is string
        } catch (Exception e) {
            Log.e("Buffer Error", "Error converting result " + e.toString());
        }

        // try parse the string to a JSON object
        try {
            jObj = new JSONObject(json);
        } catch (JSONException e) {
            Log.e("JSON Parser For Parser", "Error parsing data " + e.toString());
        }


        // return JSON String
        return jObj;

    }

//    private final AccessControlContext context = AccessController.getContext();
//    // Instantiate the RequestQueue.
//    RequestQueue queue = Volley.newRequestQueue(MyOfficeActivity.myOffActContext); // getApplicationContext());
//
//    // Request a string response from the provided URL.
//    StringRequest stringRequest =
//            new StringRequest(Request.Method.GET,
//                              strUrl,// url,
//                              new Response.Listener<String>() {
//                                @Override
//                                public void onResponse(String response) {
//                                    // Display the first 500 characters of the response string.
//                                    //textView.setText("Response is: "+ response.substring(0,500));
//                                    strResponce = response;
//                                }
//                              },
//                              new Response.ErrorListener() {
//                                @Override
//                                public void onErrorResponse(VolleyError error) {
//                                    //textView.setText("That didn't work!");
//                                    volleyError = error;
//                                    isError = true;
//                                }
//                              }
//                              );
//
//    // Add the request to the RequestQueue.
//    queue.add(stringRequest);
//

    /***********************************************************************************************
     *
     https://developer.android.com/training/volley/simple#java

     //final TextView textView = (TextView) findViewById(R.id.text);
     // ...

     // Instantiate the RequestQueue.
     RequestQueue queue = Volley.newRequestQueue(this);
     //String url ="https://www.google.com";

     // Request a string response from the provided URL.
     StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
     new Response.Listener<String>() {
    @Override
    public void onResponse(String response) {
    // Display the first 500 characters of the response string.
    textView.setText("Response is: "+ response.substring(0,500));
    }
    }, new Response.ErrorListener() {
    @Override
    public void onErrorResponse(VolleyError error) {
    textView.setText("That didn't work!");
    }
    });

     // Add the request to the RequestQueue.
     queue.add(stringRequest);

    ************************************************************************************************/
    /***********************************************************************************************
     protected String download(String url) throws Exception {
         CloseableHttpClient client = null;
         CloseableHttpResponse response = null;
         String content = null;
         InputStream stream = null;
         try {
             client = HttpClientBuilder.create().build();
             response = client.execute(new HttpGet(url));
             assertThat(response.getStatusLine().getStatusCode(), equalTo(200));

             stream = response.getEntity().getContent();
             content = IOUtils.toString(stream, "UTF-8");
         } finally {
             IOUtils.closeQuietly(stream);
             IOUtils.closeQuietly(response);
             IOUtils.closeQuietly(client);
         }

         return content;
     }
     * *********************************************************************************************/

}
