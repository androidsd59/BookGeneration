package com.qprogramming.bookgeneration

import android.app.AlertDialog
import android.app.Dialog
import android.os.Bundle
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.DialogFragment
import com.qprogramming.bookgeneration.dummy.DummyContent
import java.lang.IllegalStateException

/**
 * A fragment representing a list of Items.
 */
class ObjectSelectionDialogFragment : DialogFragment() {

    private var columnCount = 1
    private val catNames = arrayOf("Васька", "Рыжик", "Мурзик")

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        super.onCreateDialog(savedInstanceState)
        val catNames = arrayOf("Васька", "Рыжик", "Мурзик")
//        arguments?.let {
//            columnCount = it.getInt(ARG_COLUMN_COUNT)
//        }
        return activity?.let {
            val builder = AlertDialog.Builder(it)
            builder.setTitle("Search countries")
                   .setItems(catNames) { dialog, wich ->
                    Toast.makeText(activity, "country: ${catNames[wich]}",
                                    Toast.LENGTH_LONG)
                         .show()
                }
            builder.create()
        } ?: throw IllegalStateException("Activity cannot be null")
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view =
            inflater.inflate(R.layout.fragment_country_selection_dialog_list, container, false)

        // Set the adapter
        if (view is RecyclerView) {
            with(view) {
                layoutManager = when {
                    columnCount <= 1 -> LinearLayoutManager(context)
                    else -> GridLayoutManager(context, columnCount)
                }
                adapter = MyItemRecyclerViewAdapter(DummyContent.ITEMS)
            }
        }
        return view
    }

    companion object {

        // TODO: Customize parameter argument names
        const val ARG_COLUMN_COUNT = "column-count"

        // TODO: Customize parameter initialization
        @JvmStatic
        fun newInstance(columnCount: Int) =
            ObjectSelectionDialogFragment().apply {
                arguments = Bundle().apply {
                    putInt(ARG_COLUMN_COUNT, columnCount)
                }
            }
    }
}