package com.qprogramming.bookgeneration.Managers;

public class WorkplanManager {
}
