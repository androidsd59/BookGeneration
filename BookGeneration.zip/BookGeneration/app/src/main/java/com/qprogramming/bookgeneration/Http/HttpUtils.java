package com.qprogramming.bookgeneration.Http;

import android.util.Log;

//import com.qprogramming.smarttrainer.Entities.Response;

import com.qprogramming.bookgeneration.Entities.Response;

import java.util.Observable;

public class HttpUtils extends Observable {
    public void NotifyObservers(String command, Object data)
    {
        Response response = new Response();
        response.setCommand(command);
        response.setData(data);
        APdu apdu = _makeApdu(response);
        this.setChanged();
        this.notifyObservers (apdu);
    }
    private static APdu _makeApdu (Response response) {
        APdu rc = null;
        try {
            APdu.APDU_TYPE apduType = null;
            apduType = APdu.APDU_TYPE.RESPONSE;

            APdu.APDU_CMD cmd = null;
            if (apduType == APdu.APDU_TYPE.RESPONSE) cmd = APdu.APDU_CMD.valueOf (response.getcommand());

            String[] params = null;
            rc = new APdu (apduType,cmd, params, APdu.APDU_RESULT.NONE, response);
        }
        catch (Exception e) {
            Log.e ("HttpService", e.getMessage ());
        }
        return rc;
    }
}