package com.qprogramming.bookgeneration.Entities;

public class WorkPlan {
    // TODO             create body this class
}
