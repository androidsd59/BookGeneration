package com.qprogramming.bookgeneration

//import android.R
import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.content.SharedPreferences.Editor
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.os.Bundle
import android.view.View
import android.widget.RadioButton
import android.widget.RadioGroup
import androidx.appcompat.app.AppCompatActivity
import java.util.*
import android.content.Intent as Intent1


class MainActivity : AppCompatActivity() {
    val TYPE_LANGUAGE_NOT_SELECTED  = 0
    val TYPE_LANGUAGE_ENGLISH       = 1
    val TYPE_LANGUAGE_HEBREW        = 2
    val TYPE_LANGUAGE_RUSSIAN       = 3

    private var sPref: SharedPreferences? = null

    var update_activity : Boolean = false

    var type_language = TYPE_LANGUAGE_NOT_SELECTED
    val TYPE_LANG : String = "type_language"

    var rb_lang_not_set : RadioButton? = null
    var rb_lang_english : RadioButton? = null
    var rb_lang_hebrew : RadioButton? = null
    var rb_lang_russian : RadioButton? = null

    var radio_group_lang : RadioGroup? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        rb_lang_not_set = findViewById(R.id.rb_not_selected)
        rb_lang_english = findViewById(R.id.rb_english)
        rb_lang_hebrew = findViewById(R.id.rb_hebrew)
        rb_lang_russian = findViewById(R.id.rb_russian)

        radio_group_lang = findViewById(R.id.radiogroup_langs)

        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT

        sPref = getSharedPreferences("MyPref", MODE_PRIVATE)

        ControlSetLanguage()
    }

    fun ControlSetLanguage() {
        loadTypeLang()
    }

    fun onClickRBNotSelected(view: View) {
        type_language = TYPE_LANGUAGE_NOT_SELECTED
        ChangeVisibleActivity()
    }

    fun onClickRBEnglish(view: View) {
        type_language = TYPE_LANGUAGE_ENGLISH
        ChangeVisibleActivity()
    }

    fun onClickRBHebrew(view: View) {
        type_language = TYPE_LANGUAGE_HEBREW
        ChangeVisibleActivity()
    }

    fun onClickRBRussian(view: View) {
        type_language = TYPE_LANGUAGE_RUSSIAN
        ChangeVisibleActivity()
    }

    fun ChangeVisibleActivity(){
        saveTypeLang()
        loadTypeLang()
        UpadateActivity()

        //var intent_my_office : Intent1 = Intent1(this, MyOfficeActivity.class);
        //val intent_my_office = Intent1(this, MyOfficeActivity::class);
        val intent_my_office = Intent1(this, AboutUsActivity::class.java);
        startActivity(intent_my_office)

    }

    @SuppressLint("CommitPrefEdits")
    private fun saveTypeLang() {
        var ed: Editor = sPref?.edit() ?: return
        ed.putInt(TYPE_LANG, type_language)
        ed.commit()
    }

    private fun loadTypeLang() {
        type_language = sPref?.getInt(TYPE_LANG, TYPE_LANGUAGE_NOT_SELECTED) ?: TYPE_LANGUAGE_NOT_SELECTED
        radio_group_lang?.check(type_language)

        when(type_language) {
            TYPE_LANGUAGE_ENGLISH -> {
                rb_lang_english?.isChecked = true
                SetPresentLocale("en")
            }
            TYPE_LANGUAGE_HEBREW -> {
                rb_lang_hebrew?.isChecked = true
                SetPresentLocale("iw")
            }
            TYPE_LANGUAGE_RUSSIAN -> {
                rb_lang_russian?.isChecked = true
                SetPresentLocale("ru")
            }

            else -> rb_lang_not_set?.isChecked = true
        }

        //ControlSetLanguage()
    }

    fun SetPresentLocale(value_lang: String) {
        val locale = Locale(value_lang)
        Locale.setDefault(locale)
        val configuration = Configuration()
        configuration.setLocale(locale)
        baseContext.resources.updateConfiguration(configuration, null)

        // displaying English text in the changed locale of the device
        setTitle(R.string.app_name)

        UpadateActivity()
    }

    fun UpadateActivity() {
        if (update_activity == false) {
            update_activity = true
        }
        else {
            finish()
            overridePendingTransition(0, 0)
            startActivity(intent)
            overridePendingTransition(0, 0)
        }
    }

}