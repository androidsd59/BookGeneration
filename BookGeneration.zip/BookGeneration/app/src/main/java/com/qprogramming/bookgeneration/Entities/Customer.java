package com.qprogramming.bookgeneration.Entities;

import android.database.Cursor;
import android.graphics.Bitmap;

import androidx.annotation.IntDef;

import com.qprogramming.bookgeneration.DB.AppDatabaseHelper;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.List;

// TODO   uncomment this import
//import static com.qprogramming.bookgeneration.AppEnv.diskAdapter;

public class Customer {
    private String first_name = "";
    private String last_name = "";
    private String telephone = "";
    private String email = "";
    private String credit_card_number = "";
    private String credit_card_exp_date = "";
    private String credit_card_cvv = "";
    private int record_id = 0;
    private int client_id = 0;
    private Bitmap _image;

    private int physical_condition = 0;
    private int my_goal = 0;
    private int age = 0;
    private int weight = 0;
    private int height = 0;
    private int sex = 0;
    private int id = 0;
    private String token = "";

    public String getCreditCardCVV() {
        return credit_card_cvv;
    }

    public void setCreditCardCVV(String credit_card_cvv) {
        this.credit_card_cvv = credit_card_cvv;
    }

    public String getCreditCardExpDate() {
        return credit_card_exp_date;
    }

    public void setCreditCardExpDate(String credit_card_exp_date) {
        this.credit_card_exp_date = credit_card_exp_date;
    }

    public String getCreditCardNumber() {
        return credit_card_number;
    }

    public void setCreditCardNumber(String credit_card_number) {
        this.credit_card_number = credit_card_number;
    }

    public void setSex(int sex) {
        this.sex= sex;
    }
    public void setGMyGoal(int my_goal) {
        this.my_goal = my_goal;
    }
    public void setWeight(int weight) {
        this.weight = weight;
    }
    public void setHeight(int height) {
        this.height = height;
    }
    public void setPhysicalCondition(int physical_condition) {this.physical_condition = physical_condition;}
    public void setAge(int age) {
        this.age = age;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFirstName() {
        return first_name;
    }

    public void setFirstName(String first_name) {
        this.first_name = first_name;
    }

    public String getLastName() {
        return last_name;
    }

    public void setLastName(String last_name) {
        this.last_name = last_name;
    }

    public int getRecordId() {
        return record_id;
    }

    public void setRecordId(int record_id) {
        this.record_id = record_id;
    }

    public int getPhysicalCondition() {
        return physical_condition;
    }
    public int getAge() {
        return age;
    }
    public int getWeight() {
        return weight;
    }
    public int getHeight() {
        return height;
    }
    public int getMyGoal() {
        return my_goal;
    }
    public int getSex() {
        return sex;
    }

    public void setId(int id) {
        this.id = id;
    }
    public int getClientId() {
        return client_id;
    }

    public void setClientId(int client_id) {
        this.client_id = client_id;
    }

    public String getToken() {
        return token;
    }
    public void setToken(String token) {
        this.token = token;
    }
    public Bitmap getImage() { return _image; }
    public void setImage(Bitmap bitmap) { _image = bitmap; }

    public String getKey() {
        return "user_" + getClientId();
    }
    public Customer(){}

    public Customer(Cursor cursor)
    {
        if(!cursor.isNull(cursor.getColumnIndex(AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_FIRST_NAME)))
            this.first_name = cursor.getString(cursor.getColumnIndex(AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_FIRST_NAME));
        if(!cursor.isNull(cursor.getColumnIndex(AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_LAST_NAME)))
            this.last_name = cursor.getString(cursor.getColumnIndex(AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_LAST_NAME));
        if(!cursor.isNull(cursor.getColumnIndex(AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_TELEPHONE)))
            this.telephone = cursor.getString(cursor.getColumnIndex(AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_TELEPHONE));
        if(!cursor.isNull(cursor.getColumnIndex(AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_EMAIL)))
            this.email = cursor.getString(cursor.getColumnIndex(AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_EMAIL));
        if(!cursor.isNull(cursor.getColumnIndex(AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_CREDIT_CARD_NUMBER)))
            this.credit_card_number = cursor.getString(cursor.getColumnIndex(AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_CREDIT_CARD_NUMBER));
        if(!cursor.isNull(cursor.getColumnIndex(AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_CREDIT_CARD_EXP_DATE)))
            this.credit_card_exp_date = cursor.getString(cursor.getColumnIndex(AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_CREDIT_CARD_EXP_DATE));
        if(!cursor.isNull(cursor.getColumnIndex(AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_CREDIT_CARD_CVV)))
            this.credit_card_cvv = cursor.getString(cursor.getColumnIndex(AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_CREDIT_CARD_CVV));
        this.record_id = cursor.getInt(cursor.getColumnIndex(AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_RECORD_ID));
        this.client_id = cursor.getInt(cursor.getColumnIndex(AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_CLIENT_ID));

        if(!cursor.isNull(cursor.getColumnIndex(AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_AGE)))
            this.age = cursor.getInt(cursor.getColumnIndex(AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_AGE));
        if(!cursor.isNull(cursor.getColumnIndex(AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_WEIGHT)))
            this.weight = cursor.getInt(cursor.getColumnIndex(AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_WEIGHT));
        if(!cursor.isNull(cursor.getColumnIndex(AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_HEIGHT)))
            this.height = cursor.getInt(cursor.getColumnIndex(AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_HEIGHT));
        if(!cursor.isNull(cursor.getColumnIndex(AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_GOAL)))
            this.my_goal = cursor.getInt(cursor.getColumnIndex(AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_GOAL));
        if(!cursor.isNull(cursor.getColumnIndex(AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_PHYSICAL_CONDITION)))
            this.physical_condition = cursor.getInt(cursor.getColumnIndex(AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_PHYSICAL_CONDITION));
        if(!cursor.isNull(cursor.getColumnIndex(AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_SEX)))
            this.sex = cursor.getInt(cursor.getColumnIndex(AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_SEX));

       // _image = diskAdapter.readFromDiskCache(getKey());
        //Get firebase token
        // TODO  uncomment this code !
//        com.qprogramming.bookgeneration.MyFirebaseInstanceIDService myFirebaseInstanceIDService = new com.qprogramming.bookgeneration.MyFirebaseInstanceIDService();
//        this.token = myFirebaseInstanceIDService.getToken();
    }

}
