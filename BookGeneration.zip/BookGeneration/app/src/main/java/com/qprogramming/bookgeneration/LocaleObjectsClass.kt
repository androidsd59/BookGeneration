package com.qprogramming.bookgeneration

import android.content.Context
import android.content.SharedPreferences
import android.content.res.Configuration
import java.util.*

public final class LocaleObjectsClass(context: Context){
    val TYPE_LANGUAGE_NOT_SELECTED  = 0
    val TYPE_LANGUAGE_ENGLISH       = 1
    val TYPE_LANGUAGE_HEBREW        = 2
    val TYPE_LANGUAGE_RUSSIAN       = 3

    var type_language = TYPE_LANGUAGE_NOT_SELECTED
    val TYPE_LANG : String = "type_language"

    private var sPref: SharedPreferences? = null

    lateinit var this_context : Context
    init {
        this_context = context
    }

    fun ControlSetLanguage() {
        loadTypeLang()
    }

    private fun loadTypeLang() : Int {
        type_language = sPref?.getInt(TYPE_LANG, TYPE_LANGUAGE_NOT_SELECTED) ?: TYPE_LANGUAGE_NOT_SELECTED

        when(type_language) {
            TYPE_LANGUAGE_ENGLISH -> {
                SetPresentLocale("en")
            }
            TYPE_LANGUAGE_HEBREW -> {
                SetPresentLocale("iw")
            }
            TYPE_LANGUAGE_RUSSIAN -> {
                SetPresentLocale("ru")
            }
        }

        return type_language
    }

    //fun SetPresentLocale(context : Context,  value_lang: String) {
    fun SetPresentLocale(value_lang: String) {
        val locale = Locale(value_lang)
        Locale.setDefault(locale)
        val configuration = Configuration()
        configuration.setLocale(locale)
        //baseContext.resources.updateConfiguration(configuration, null)
        this_context.resources.updateConfiguration(configuration, null)

        // displaying English text in the changed locale of the device
        //setTitle(R.string.app_name)
    }

}