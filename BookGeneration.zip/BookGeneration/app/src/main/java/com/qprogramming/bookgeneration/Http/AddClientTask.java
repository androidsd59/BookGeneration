package com.qprogramming.bookgeneration.Http;

import android.os.AsyncTask;
import android.util.Log;

import com.qprogramming.bookgeneration.AppEnv;
import com.qprogramming.bookgeneration.Entities.Customer;
import com.qprogramming.bookgeneration.Managers.ClientManager;
import com.qprogramming.bookgeneration.Util.DiskLruCacheAdapter;

import java.io.IOException;

import static com.qprogramming.bookgeneration.AppEnv.diskAdapter;

// TODO  add  import org.apache.http.*      //       2020.11.04   16:26
/***********************************************************************
import org.apache.http.HttpResponse;                                                                  //       2020.11.04   16:26
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.HTTP;
 /************************************************************************/

public class AddClientTask extends AsyncTask<Customer, Void, Customer> {
    protected Customer doInBackground(Customer... customer) {
        ClientManager manager = new ClientManager();
        try {
            if(AppEnv.Personal.getClientId() == 0)
                manager.insert(customer[0]);
            } catch (Exception e) {

        }
        try {
            if (diskAdapter.getBitmapFromDiskCache(customer[0].getKey()) == null && customer[0].getImage()!=null) {
                new DiskLruCacheAdapter().addBitmapToCache(customer[0].getKey(), customer[0].getImage());
        }
        } catch (IOException e) {
            Log.e ("AddClientTask", e.getMessage (), e);
        }

        return manager.send(customer[0]);
    }

    @Override
    protected void onPostExecute(Customer client) {
        try {
            AppEnv.Personal.setClientId(client.getClientId());
            ClientManager manager = new ClientManager();
            manager.update_client_id(AppEnv.Personal.getClientId());
            // TODO add  new GetWorkPlansTask().execute(AppEnv.Personal.getClientId());
       //     new GetWorkPlansTask().execute(AppEnv.Personal.getClientId());                        2020.11.04   16:26
        }
        catch (Exception e)
        {
            Log.e ("AddClientTask", e.getMessage (), e);
        }
    }

}

