package com.qprogramming.bookgeneration.DB;

import android.content.ContentValues;
import android.database.Cursor;

import static com.qprogramming.bookgeneration.AppEnv.db;
import com.qprogramming.bookgeneration.Entities.Customer;

public class PersonalData {

    synchronized public Customer readData () {
        String sql = "select * from " + AppDatabaseHelper.TABLE_PERSONAL_DATA;
        Cursor cursor =  db.rawQuery (sql, null);
        Customer client = new Customer();
        while (cursor.moveToNext()) {
            client = new Customer (cursor);
        }
        cursor.close();
        return client;
    }

    synchronized public void clearResults () throws Exception {
        try {
            //db.execSQL ("delete from " + AppDatabaseHelper.TABLE_DEPARTMENTS);
        }
        catch (Exception e) {
            throw e;
        }
    }

    synchronized public void apply(String first_name,	String last_name, String telephone, String email,
                                   String credit_card_number, String credit_card_exp_date, String credit_card_cvv,
                                   int age, int weight, int height, int goal, int physical_condition, int sex,
                                   int laundry_id)
    {
        ContentValues values = new ContentValues ();
        values.put (AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_FIRST_NAME, first_name);
        values.put (AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_LAST_NAME, last_name);
        values.put (AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_TELEPHONE, telephone);
        values.put (AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_EMAIL, email);
        values.put (AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_CREDIT_CARD_NUMBER, credit_card_number);
        values.put (AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_CREDIT_CARD_EXP_DATE, credit_card_exp_date);
        values.put (AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_CREDIT_CARD_CVV, credit_card_cvv);
        values.put (AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_AGE, age);
        values.put (AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_HEIGHT, height);
        values.put (AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_WEIGHT, weight);
        values.put (AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_GOAL, goal);
        values.put (AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_SEX, sex);
        values.put (AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_PHYSICAL_CONDITION, physical_condition);
        db.update(AppDatabaseHelper.TABLE_PERSONAL_DATA, values, null, null);
    }

    synchronized public long insert(String first_name,	String last_name, String telephone,String email, String credit_card_number,
                                    String credit_card_exp_date, String credit_card_cvv,
                                    int age, int weight, int height, int goal, int physical_condition, int sex,
                                    int gym_id)
    {
        ContentValues values = new ContentValues ();
        values.put (AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_FIRST_NAME, first_name);
        values.put (AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_LAST_NAME, last_name);
        values.put (AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_TELEPHONE, telephone);
        values.put (AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_EMAIL, email);
        values.put (AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_CREDIT_CARD_NUMBER, credit_card_number);
        values.put (AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_CREDIT_CARD_EXP_DATE, credit_card_exp_date);
        values.put (AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_CREDIT_CARD_CVV, credit_card_cvv);
        values.put (AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_AGE, age);
        values.put (AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_HEIGHT, height);
        values.put (AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_WEIGHT, weight);
        values.put (AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_GOAL, goal);
        values.put (AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_SEX, sex);
        values.put (AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_PHYSICAL_CONDITION, physical_condition);
        values.put (AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_RECORD_ID, "0");
        return db.insert(AppDatabaseHelper.TABLE_PERSONAL_DATA, null, values);
    }
    synchronized public void update_client_id(int client_id)
    {
        ContentValues values = new ContentValues ();
        values.put (AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_CLIENT_ID, client_id);
        db.update(AppDatabaseHelper.TABLE_PERSONAL_DATA, values, null, null);
    }

    synchronized public void update_record_id(int record_id)
    {
        ContentValues values = new ContentValues ();
        values.put (AppDatabaseHelper.COLUMN_TABLE_PERSONAL_DATA_RECORD_ID, record_id);
        db.update(AppDatabaseHelper.TABLE_PERSONAL_DATA, values, null, null);
    }

}
