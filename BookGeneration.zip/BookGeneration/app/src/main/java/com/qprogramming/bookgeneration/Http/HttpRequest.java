package com.qprogramming.bookgeneration.Http;

import android.os.AsyncTask;
import android.util.Log;

import com.qprogramming.bookgeneration.AppEnv;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

//import com.qprogramming.smarttrainer.AppEnv;

public class HttpRequest  {

    public void Test()
    {
        AsyncTask.execute (new Runnable () {
            @Override
            public void run() {
                try {
                    URL json = new URL(AppEnv.url);
                    Log.d("Test", AppEnv.url);
                    URLConnection jc = json.openConnection();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(jc.getInputStream()));
                    String line = reader.readLine();
                }
                catch (Exception e) {
                    Log.e ("Test", e.getMessage() != null ? e.getMessage() : e.getClass().getName());
                }
            }
        });
    }
}