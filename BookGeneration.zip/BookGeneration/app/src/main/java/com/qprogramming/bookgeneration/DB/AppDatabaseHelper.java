package com.qprogramming.bookgeneration.DB;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

public class AppDatabaseHelper extends SQLiteOpenHelper {

        private Context context;

        public static final String TABLE_EXERCISES = "exercises";
        public static final String TABLE_EXERCISE_SETS = "exercise_sets";
        public static final String TABLE_MUSCLES_GROUPS = "muscles_groups";
        public static final String TABLE_PERSONAL_DATA = "personal_data";
        public static final String TABLE_WORKPLANS = "workplans";
        public static final String TABLE_TIPS = "tips";
        public static final String TABLE_VERSIONS = "versions";
        public static final String TABLE_GYM_INFO = "gym_info";
        public static final String TABLE_MESSAGES = "messages";
        public static final String TABLE_TRAINING_DAYS = "training_days";

        public static final String COLUMN_ID = "_id";

        public static final String COLUMN_MUSCLES_GROUPS_ID = "group_id";
        public static final String COLUMN_MUSCLES_GROUPS_NAME = "name";
        public static final String COLUMN_MUSCLES_GROUPS_DESCRIPTION = "description";
        public static final String COLUMN_MUSCLES_GROUPS_IMAGE = "image";

        public static final String COLUMN_EXERCISES_DESCRIPTION = "description";
        public static final String COLUMN_EXERCISES_WORK_PLAN_ID = "workplan_id";
        public static final String COLUMN_EXERCISES_NAME = "name";
        public static final String COLUMN_EXERCISES_VIDEO = "video_link";
        public static final String COLUMN_EXERCISES_IMAGE = "image";
        public static final String COLUMN_EXERCISES_REST_TIME = "rest_time";
        public static final String COLUMN_EXERCISES_MUSCLES_GROUP_ID = "group_id";
        public static final String COLUMN_EXERCISES_VOICE = "voice_link";
        public static final String COLUMN_EXERCISES_DAY = "day";

        public static final String COLUMN_EXERCISE_SETS_SET_NUMBER = "set_number";
        public static final String COLUMN_EXERCISE_SETS_EXECUTION_TIME = "exec_time";
        public static final String COLUMN_EXERCISE_SETS_EXERCISE_ID = "exercise_id";
        public static final String COLUMN_EXERCISE_SETS_KG = "kg";
        public static final String COLUMN_EXERCISE_SETS_MINUTES = "minutes";
        public static final String COLUMN_EXERCISE_SETS_REPS = "reps";
        public static final String COLUMN_EXERCISE_SETS_RESTING_TIME = "rest_time";

        public static final String COLUMN_VERSIONS_OBJECT = "object";
        public static final String COLUMN_VERSIONS_NUMBER = "number";

        public static final String COLUMN_WORKPLANS_NAME = "name";
        public static final String COLUMN_WORKPLANS_DESCRIPTION = "description";
        public static final String COLUMN_WORKPLANS_ID = "workplan_id";
        public static final String COLUMN_WORKPLANS_TYPE = "type"; //porpose
        public static final String COLUMN_WORKPLANS_LEVEL = "level";
        public static final String COLUMN_WORKPLANS_AGE_FROM = "age_from";
        public static final String COLUMN_WORKPLANS_AGE_TO = "age_to";
        public static final String COLUMN_WORKPLANS_SEX = "sex";
        public static final String COLUMN_WORKPLANS_IMAGE = "image";
        public static final String COLUMN_WORKPLANS_IS_OWNER = "is_owner";
        public static final String COLUMN_WORKPLANS_OWNER_IMAGE = "owner_image";
        public static final String COLUMN_WORKPLANS_GOAL = "goal";
        public static final String COLUMN_WORKPLANS_TRAINING_DAYS = "training_days";

        public static final String COLUMN_TRAINING_DAYS_DAY = "day";
        public static final String COLUMN_TRAINING_DAYS_DURING_TIME = "during_time";

        public static final String COLUMN_TABLE_PERSONAL_DATA_CLIENT_ID = "client_id";
        public static final String COLUMN_TABLE_PERSONAL_DATA_FIRST_NAME = "first_name";
        public static final String COLUMN_TABLE_PERSONAL_DATA_LAST_NAME = "last_name";
        public static final String COLUMN_TABLE_PERSONAL_DATA_POST_CODE = "post_code";
        public static final String COLUMN_TABLE_PERSONAL_DATA_CITY = "city";
        public static final String COLUMN_TABLE_PERSONAL_DATA_CITY_ID = "city_id";
        public static final String COLUMN_TABLE_PERSONAL_DATA_ADDRESS_LINE = "address_line";
        public static final String COLUMN_TABLE_PERSONAL_DATA_TELEPHONE = "telephone";
        public static final String COLUMN_TABLE_PERSONAL_DATA_EMAIL = "email";
        public static final String COLUMN_TABLE_PERSONAL_DATA_CREDIT_CARD_NUMBER = "credit_card_number";
        public static final String COLUMN_TABLE_PERSONAL_DATA_CREDIT_CARD_EXP_DATE = "credit_card_exp_date";
        public static final String COLUMN_TABLE_PERSONAL_DATA_CREDIT_CARD_CVV = "credit_card_cvv";
        public static final String COLUMN_TABLE_PERSONAL_DATA_GYM_ID = "gym_id";
        public static final String COLUMN_TABLE_PERSONAL_DATA_RECORD_ID = "record_id";

        public static final String COLUMN_TABLE_PERSONAL_DATA_AGE = "age";
        public static final String COLUMN_TABLE_PERSONAL_DATA_WEIGHT = "weight";
        public static final String COLUMN_TABLE_PERSONAL_DATA_HEIGHT = "height";
        public static final String COLUMN_TABLE_PERSONAL_DATA_GOAL = "my_goal";
        public static final String COLUMN_TABLE_PERSONAL_DATA_PHYSICAL_CONDITION = "physical_condition";
        public static final String COLUMN_TABLE_PERSONAL_DATA_SEX = "sex";

        public static final String COLUMN_TABLE_GYM_INFO_ID = "gym_id";
        public static final String COLUMN_TABLE_GYM_INFO_NAME = "gym_name";
        public static final String COLUMN_TABLE_GYM_INFO_TELEPHONE = "telephone";
        public static final String COLUMN_TABLE_GYM_INFO_ADDRESS = "address_line";
        public static final String COLUMN_TABLE_GYM_INFO_HEADER = "header";
        public static final String COLUMN_TABLE_GYM_INFO_CITY = "city";

        public static final String COLUMN_TABLE_MESSAGES_ID = "message_id";
        public static final String COLUMN_TABLE_MESSAGES_CREATED_DATE = "created_date";
        public static final String COLUMN_TABLE_MESSAGES_TEXT = "text";

        public static final String COLUMN_TABLE_TIPS_IMAGE = "image";
        public static final String COLUMN_TABLE_TIPS_NAME = "name";
        public static final String COLUMN_TABLE_TIPS_DESCRIPTION = "description";

        public static final String TABLE_EXERCISE_VIDEOS = "exercise_videos";
        public static final String COLUMN_EXERCISE_VIDEOS_EXERCISE_ID = "exercise_id";
        public static final String COLUMN_EXERCISE_VIDEOS_VIDEO_ID = "id";
        public static final String COLUMN_EXERCISE_VIDEOS_LINK = "path";
        public static final String COLUMN_EXERCISE_VIDEOS_TYPE = "type";

        private static final String DATABASE_NAME = "smart_trainer.db";
        private static final int DATABASE_VERSION = 1;

        // Database creation sql statement
        private static final String DATABASE_CREATE_MUSCLES_GROUPS = "create table "
                + TABLE_MUSCLES_GROUPS + "( " + COLUMN_ID
                + " integer not null, " + COLUMN_MUSCLES_GROUPS_NAME
                + " text not null, " + COLUMN_MUSCLES_GROUPS_DESCRIPTION
                + " text not null, " + COLUMN_MUSCLES_GROUPS_ID
                + " INTEGER not null, " + COLUMN_MUSCLES_GROUPS_IMAGE
                + " text not null); ";

        private static final String DATABASE_CREATE_TABLE_EXERCISES = "create table "
                + TABLE_EXERCISES + "( " + COLUMN_ID
                + " integer primary key autoincrement, " + COLUMN_EXERCISES_WORK_PLAN_ID
                + " integer not null, " + COLUMN_EXERCISES_NAME
                + " text not null, " + COLUMN_EXERCISES_DESCRIPTION
                + " text not null, " + COLUMN_EXERCISES_VIDEO
                + " text not null, " + COLUMN_EXERCISES_VOICE
                + " text not null, " + COLUMN_EXERCISES_DAY
                + " integer not null, " + COLUMN_EXERCISES_IMAGE
                + " text not null, " + COLUMN_EXERCISES_REST_TIME
                + " text not null, " + COLUMN_EXERCISES_MUSCLES_GROUP_ID
                + " INTEGER not null);";

        private static final String DATABASE_CREATE_TABLE_EXERCISE_SETS = "create table "
                + TABLE_EXERCISE_SETS + "( " + COLUMN_ID
                + " integer not null, " + COLUMN_EXERCISE_SETS_EXERCISE_ID
                + " integer not null, " + COLUMN_EXERCISE_SETS_SET_NUMBER
                + " integer not null, " + COLUMN_EXERCISE_SETS_EXECUTION_TIME
                + " integer not null, " + COLUMN_EXERCISE_SETS_KG
                + " integer not null, " + COLUMN_EXERCISE_SETS_MINUTES
                + " integer not null, " + COLUMN_EXERCISE_SETS_REPS
                + " integer not null, " + COLUMN_EXERCISE_SETS_RESTING_TIME
                + " INTEGER not null);";

        private static final String DATABASE_CREATE_TABLE_EXERCISE_VIDEOS = "create table "
                + TABLE_EXERCISE_VIDEOS + "( " + COLUMN_EXERCISE_VIDEOS_VIDEO_ID
                + " integer primary key autoincrement, " + COLUMN_EXERCISE_VIDEOS_EXERCISE_ID
                + " integer not null, " + COLUMN_EXERCISE_VIDEOS_LINK
                + " text not null, " + COLUMN_EXERCISE_VIDEOS_TYPE
                + " integer not null);";

        private static final String DATABASE_CREATE_VERSIONS = "create table "
                + TABLE_VERSIONS + "( " + COLUMN_VERSIONS_OBJECT
                + " integer not null, " + COLUMN_VERSIONS_NUMBER
                + " integer not null); ";

        private static final String DATABASE_CREATE_TABLE_WORKPLANS = "create table "
                + TABLE_WORKPLANS + "( " + COLUMN_WORKPLANS_ID
                + " integer not null," + COLUMN_WORKPLANS_TYPE
                + " integer DEFAULT 0," + COLUMN_WORKPLANS_SEX
                + " integer DEFAULT 0," + COLUMN_WORKPLANS_NAME
                + " text not null," + COLUMN_WORKPLANS_DESCRIPTION
                + " text not null," + COLUMN_WORKPLANS_IMAGE
                + " text not null," + COLUMN_WORKPLANS_AGE_FROM
                + " integer not null," + COLUMN_WORKPLANS_AGE_TO
                + " integer not null," + COLUMN_WORKPLANS_LEVEL
                + " integer not null," + COLUMN_WORKPLANS_GOAL
                + " integer not null," + COLUMN_WORKPLANS_TRAINING_DAYS
                + " integer not null," + COLUMN_WORKPLANS_IS_OWNER
                + " integer DEFAULT 0," + COLUMN_WORKPLANS_OWNER_IMAGE
                + " text DEFAULT null);";

        private static final String DATABASE_CREATE_TIPS = "create table "
                + TABLE_TIPS + "( " + COLUMN_ID
                + " integer primary key autoincrement, " + COLUMN_TABLE_TIPS_IMAGE
                + " text not null," + COLUMN_TABLE_TIPS_NAME
                + " text not null," + COLUMN_TABLE_TIPS_DESCRIPTION
                + " text not null); ";

        private static final String DATABASE_CREATE_PERSONAL_DATA = "create table "
                + TABLE_PERSONAL_DATA + "( " + COLUMN_TABLE_PERSONAL_DATA_GYM_ID
                + " integer DEFAULT 0," + COLUMN_TABLE_PERSONAL_DATA_CLIENT_ID
                + " integer DEFAULT 0," + COLUMN_TABLE_PERSONAL_DATA_RECORD_ID
                + " integer DEFAULT 0," + COLUMN_TABLE_PERSONAL_DATA_FIRST_NAME
                + " text DEFAULT null," + COLUMN_TABLE_PERSONAL_DATA_LAST_NAME
                + " text DEFAULT null," + COLUMN_TABLE_PERSONAL_DATA_POST_CODE
                + " text DEFAULT null," + COLUMN_TABLE_PERSONAL_DATA_CITY
                + " text DEFAULT null," + COLUMN_TABLE_PERSONAL_DATA_CITY_ID
                + " integer DEFAULT null," + COLUMN_TABLE_PERSONAL_DATA_ADDRESS_LINE
                + " text DEFAULT  null," + COLUMN_TABLE_PERSONAL_DATA_TELEPHONE
                + " text DEFAULT null," + COLUMN_TABLE_PERSONAL_DATA_EMAIL
                + " text DEFAULT null," + COLUMN_TABLE_PERSONAL_DATA_CREDIT_CARD_NUMBER
                + " text DEFAULT null," + COLUMN_TABLE_PERSONAL_DATA_CREDIT_CARD_EXP_DATE
                + " text DEFAULT null," + COLUMN_TABLE_PERSONAL_DATA_CREDIT_CARD_CVV
                + " text DEFAULT null," + COLUMN_TABLE_PERSONAL_DATA_AGE
                + " integer DEFAULT 0," + COLUMN_TABLE_PERSONAL_DATA_HEIGHT
                + " integer DEFAULT 0," + COLUMN_TABLE_PERSONAL_DATA_WEIGHT
                + " integer DEFAULT 0," + COLUMN_TABLE_PERSONAL_DATA_GOAL
                + " integer DEFAULT 0," + COLUMN_TABLE_PERSONAL_DATA_PHYSICAL_CONDITION
                + " integer DEFAULT 0," + COLUMN_TABLE_PERSONAL_DATA_SEX
                + " integer DEFAULT 0); ";

        private static final String DATABASE_CREATE_GYM_INFO = "create table "
                + TABLE_GYM_INFO + "( " + COLUMN_TABLE_GYM_INFO_ID
                + " integer not null, " + COLUMN_TABLE_GYM_INFO_NAME
                + " text not null, " + COLUMN_TABLE_GYM_INFO_TELEPHONE
                + " text not null, " + COLUMN_TABLE_GYM_INFO_ADDRESS
                + " text not null, " + COLUMN_TABLE_GYM_INFO_HEADER
                + " text not null, " + COLUMN_TABLE_GYM_INFO_CITY
                + " text);";

        private static final String DATABASE_CREATE_MESSAGES = "create table "
                + TABLE_MESSAGES + "( " + COLUMN_ID
                + " integer primary key autoincrement, " + COLUMN_TABLE_MESSAGES_ID +
                " integer not null, " + COLUMN_TABLE_MESSAGES_CREATED_DATE
                + " text not null, " + COLUMN_TABLE_MESSAGES_TEXT
                + " text not null);";

        private static final String DATABASE_CREATE_TRAINING_DAYS = "create table "
                + TABLE_TRAINING_DAYS + "( " + COLUMN_TRAINING_DAYS_DAY
                + " integer not null, " + COLUMN_TRAINING_DAYS_DURING_TIME
                + " integer not null); ";

        public AppDatabaseHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
            this.context = context;
        }


        @Override
        public void onCreate(SQLiteDatabase db) {
            try {
                db.execSQL(DATABASE_CREATE_PERSONAL_DATA);
                db.execSQL(DATABASE_CREATE_MUSCLES_GROUPS);
                db.execSQL(DATABASE_CREATE_TABLE_EXERCISES);
                db.execSQL(DATABASE_CREATE_TABLE_WORKPLANS);
                db.execSQL(DATABASE_CREATE_TABLE_EXERCISE_SETS);
                db.execSQL(DATABASE_CREATE_GYM_INFO);
                db.execSQL(DATABASE_CREATE_TIPS);
                db.execSQL(DATABASE_CREATE_MESSAGES);
                db.execSQL(DATABASE_CREATE_TRAINING_DAYS);
                db.execSQL(DATABASE_CREATE_TABLE_EXERCISE_VIDEOS);
            } catch (Exception ex) {
                Toast.makeText(context.getApplicationContext(), "Error during creation database!!",
                        Toast.LENGTH_SHORT).show();
            }
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            Log.w(AppDatabaseHelper.class.getName(),
                    "Upgrading database from version " + oldVersion + " to "
                            + newVersion + ", which will destroy all old data");
            //if (oldVersion < 1) {
            //    db.execSQL("ALTER TABLE " + TABLE_EXERCISES + " ADD COLUMN " + COLUMN_DEPARTMENTITEMS_PRICE_LIST + " INTEGER DEFAULT 0");
            //}
        }
    }
