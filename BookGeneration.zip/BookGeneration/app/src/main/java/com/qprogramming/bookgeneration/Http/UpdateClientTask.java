package com.qprogramming.bookgeneration.Http;

import android.os.AsyncTask;

import com.qprogramming.bookgeneration.AppEnv;
import com.qprogramming.bookgeneration.Entities.Customer;
import com.qprogramming.bookgeneration.Managers.ClientManager;

//import com.qprogramming.smarttrainer.AppEnv;
//import com.qprogramming.smarttrainer.Entities.Customer;
//import com.qprogramming.smarttrainer.Managers.ClientManager;

public class UpdateClientTask extends AsyncTask<Customer, Void, Customer> {
    protected Customer doInBackground(Customer... customer) {
        ClientManager manager = new ClientManager();
        return manager.send(customer[0]);
    }

    @Override
    protected void onPostExecute(Customer client) {
        // TODO  uncomment this operator
//        new GetWorkPlansTask().execute(AppEnv.Personal.getClientId());
    }

}

