package com.qprogramming.bookgeneration.Http;

import android.content.Context;
import android.os.AsyncTask;
import android.os.FileUtils;
import android.util.Log;
import android.widget.Toast;

import com.qprogramming.bookgeneration.AppEnv;
import com.qprogramming.bookgeneration.Entities.WorkPlan;
import com.qprogramming.bookgeneration.OtherMainActivity;
import com.qprogramming.bookgeneration.Managers.WorkplanManager;
// TODO   uncomment  import com.qprogramming.bookgeneration.Util.uploadfiles.FileUtils;
//import com.qprogramming.bookgeneration.Util.uploadfiles.FileUtils;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.HTTP;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONStringer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

//  TODO   uncomment this import libreries
//import static com.qprogramming.smarttrainer.Screens.Activities.AddPlanActivity.pd;
//import static com.qprogramming.smarttrainer.AppEnv.diskAdapter;

public class AddWorkPlanTask //extends AsyncTask<WorkPlan, Void, WorkPlan>
{
    Boolean _isNew = false;
    Context ctx;

    WorkPlan work_plan;

    public AddWorkPlanTask(Context context){
        ctx = context;
    }

    // TODO  uncomment body of code this class
    /***********************************************************************************************
     protected WorkPlan doInBackground(WorkPlan... workPlans) {
        work_plan = workPlans[0];
        HttpPost request = null;
        if(work_plan.GetId() == 0)
            request = new HttpPost(AppEnv.url + "/AddWorkPlan");
        else
            request = new HttpPost(AppEnv.url + "/UpdateWorkPlan");
        request.setHeader("Accept", "application/json");
        request.setHeader("Content-type", "application/json");
        try
        {
            JSONStringer vehicle = new JSONStringer()
               .object()
                    .key("workplan")
                      .object()
                        .key("ClientId").value(work_plan.GetOwner())
                        .key("ID").value(work_plan.GetId())
                        .key("Name").value(work_plan.GetTitle())
                        .key("Description").value(work_plan.GetDescription())
                        .key("AgeFrom").value(work_plan.GetAgeFrom())
                        .key("AgeTo").value(work_plan.GetAgetTo())
                        .key("Sex").value(work_plan.GetSex())
                        //Personal Condition
                        .key("Level").value(work_plan.GetLevel())
                        .key("WeightFrom").value(30)
                        .key("WeightTo").value(120)
                        //.key("Image").value(work_plan.GetImage())
                        .key("Image").value("image")
                        .key("Goal").value(work_plan.GetGoal())
                        .key("TrainingDays").value(work_plan.GetTrainingDays())
                      .endObject()
               .endObject();

            StringEntity entity = new StringEntity(vehicle.toString(), HTTP.UTF_8);
            request.setEntity(entity);

            // Send request to WCF service
            DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpResponse response = httpClient.execute(request);
            int code = response.getStatusLine().getStatusCode();
            Log.e("JSON Parser", "  Before  "+code);
            if(code == 200)
            {
                Log.e("JSON Parser", "  200 200 200");
                BufferedReader reader = new BufferedReader(new InputStreamReader(response.getEntity().getContent(), "UTF-8"));
                String json = reader.readLine();
                try {
                    JSONObject jObj = new JSONObject(json);
                    if(work_plan.GetId() == 0) {
                        _isNew = true;
                        work_plan.SetId(jObj.getInt("AddWorkPlanResult"));
                    }
                } catch (JSONException e) {
                    Log.e("JSON Parser", "Error parsing data " + e.toString());
                }
            }
        } catch (Exception e) {
            Log.e("Send workplan", "Error " + e.toString());
            return work_plan;
        }

        return work_plan;
    }
     ************************************************************************************************/
    //    @Override
    protected void onPostExecute(WorkPlan work_plan) {
     /************************************************************************************************
        try {
            WorkplanManager manager = new WorkplanManager();
            if(_isNew) {
                manager.Insert(work_plan);
                Toast.makeText(ctx,"New Work Plan added",Toast.LENGTH_LONG).show();
            }else{
                manager.Update(work_plan);
                Toast.makeText(ctx,"The Work Plan Updated",Toast.LENGTH_LONG).show();
            }
            //Upload image
            if(work_plan.getImage() != null){
                try {
                    if (diskAdapter.getBitmapFromDiskCache(work_plan.getKey()) == null) {
                        //Toast.makeText(ctx,"444",Toast.LENGTH_LONG).show();
                        diskAdapter.addBitmapToCache(work_plan.getKey(), work_plan.getImage());
                        //MainActivity.httpUtils.NotifyObservers(APdu.APDU_CMD.refresh_image.toString(), getKey());
                        Log.e("Fixxx","Yes");
                    }
                } catch (IOException e) {
                    OtherMainActivity.httpUtils.NotifyObservers(APdu.APDU_CMD.add_workplan.toString(), "failed");
                    Toast.makeText(ctx,"Error occurred",Toast.LENGTH_LONG).show();
                    Log.e("onBitmapLoaded", e.getLocalizedMessage());
                }
                //Toast.makeText(ctx,"M M M",Toast.LENGTH_LONG).show();
                FileUtils.includesForUploadWorkplanFiles(ctx, work_plan.getImage(), 1, work_plan.getKey(), work_plan);
                OtherMainActivity.httpUtils.NotifyObservers(APdu.APDU_CMD.add_workplan.toString(), "ok");
            }else {
                OtherMainActivity.httpUtils.NotifyObservers(APdu.APDU_CMD.add_workplan.toString(), "ok");
                Toast.makeText(ctx,"Error occurred",Toast.LENGTH_LONG).show();
            }
        }
        catch (Exception e)
        {
            OtherMainActivity.httpUtils.NotifyObservers(APdu.APDU_CMD.add_workplan.toString(), "failed");
            Toast.makeText(ctx,"Error occurred",Toast.LENGTH_LONG).show();
            Log.e ("UpdateWorkPlanTask", e.getMessage (), e);
        }
     ************************************************************************************************/
    }


}