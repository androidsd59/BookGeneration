package com.qprogramming.bookgeneration.Http;

import android.os.AsyncTask;

//import com.qprogramming.smarttrainer.AppEnv;

import com.qprogramming.bookgeneration.AppEnv;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.HTTP;
import org.json.JSONException;
import org.json.JSONStringer;

import java.io.IOException;

public class UpdateWorkplanPhotoTask extends AsyncTask<String, Void, Boolean> {

    protected Boolean doInBackground(String... params) {
        String workplanId = params[0];
        String fileKey = params[1];
        Boolean result = false;
        try {
            HttpPost request = new HttpPost(AppEnv.url + "/UploadImage");
            request.setHeader("Accept", "application/json");
            request.setHeader("Content-type", "application/json");

            JSONStringer vehicle = new JSONStringer()
                    .object()
                    .key("workplanId").value(Integer.parseInt(workplanId))
                    .key("fileKey").value(fileKey)
                    .endObject();


            StringEntity entity = new StringEntity(vehicle.toString(), HTTP.UTF_8);
            request.setEntity(entity);

            // Send request to WCF service
            DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpResponse response = httpClient.execute(request);
            int code = response.getStatusLine().getStatusCode();
            if (code == 200) {
                result = true;
            }
            return true;
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return result;
    }
    @Override
    protected void onPostExecute(Boolean result) {
    }

}



