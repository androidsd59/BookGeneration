package com.qprogramming.bookgeneration.Http;

import android.os.AsyncTask;
import android.os.Message;
import android.util.Log;

//import com.qprogramming.smarttrainer.AppEnv;
//import com.qprogramming.smarttrainer.Entities.Message;
//import com.qprogramming.smarttrainer.MainActivity;
//import com.qprogramming.smarttrainer.Managers.ClientManager;

import com.qprogramming.bookgeneration.AppEnv;
import com.qprogramming.bookgeneration.MainActivity;
import com.qprogramming.bookgeneration.Managers.ClientManager;

import org.json.JSONException;
import org.json.JSONObject;

public class GetMessageTask extends AsyncTask<String, Void, Message> {
    protected Message doInBackground(String... params) {
        try {
            Message message = new Message();

            JSONParser jParser = new JSONParser();

            // getting JSON string from URL
            JSONObject json = jParser.getJSONFromUrl(AppEnv.url + "/GetClientMessage/" + params[0] + "/" + params[1] + "/" + params[2]);

            // TODO  uncomment this code
//            try {
//                if(json != null)
//                {
//                    message.setCommand(json.getJSONObject("GetClientMessageResult").getString("CommandName"));
//                    message.setData(json.getJSONObject("GetClientMessageResult").getString("Data"));
//                    message.setRecordId(json.getJSONObject("GetClientMessageResult").getInt("RecordId"));
//                }
//            }
//            catch (JSONException e) {
//                e.printStackTrace();
//            }
            return message;
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    protected void onPostExecute(Message message) {

        // TODO  uncomment this code
        /*********************************************************************
        if(message.getRecordId() > 0)
        {
            ClientManager client_manager = new ClientManager();
            client_manager.update_record_id(message.getRecordId());
            AppEnv.Personal.setRecordId(message.getRecordId());
            if(message.getCommand().equals("update_workplan"))
            {
            }
            if(message.getCommand().equals("add_tip"))
            {
            }
            else if(message.getCommand().equals("update_gym_info"))
            {
                try
                {
                }
                catch(Exception ex)
                {
                    Log.d("Update laundry info", ex.getMessage());
                }
            }
        }

        MainActivity.httpUtils.NotifyObservers("get_message", message);
         ***************************************************************************/
    }

}
