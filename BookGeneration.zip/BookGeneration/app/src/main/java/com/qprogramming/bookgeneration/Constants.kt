package com.qprogramming.bookgeneration

public final class Constants{
    public final val TYPE_LANGUAGE_NOT_SELECTED  = 0
    public final val TYPE_LANGUAGE_ENGLISH       = 1
    public final val TYPE_LANGUAGE_HEBREW        = 2
    public final val TYPE_LANGUAGE_RUSSIAN       = 3

    // status_lenguage ----------------
    public final val STATUS_LANGUAGE_SET_DISABLE = 0
    public final val STATUS_LANGUAGE_SET_ENABLE  = 1

    public final val TYPE_LANG = "type_language"

    public final val NAME_FILE_SHARED_PREFERENCES = "MyPref"

}