package com.qprogramming.bookgeneration.Http;

import android.os.AsyncTask;
import android.util.Log;

//import com.qprogramming.smarttrainer.AppEnv;
//import com.qprogramming.smarttrainer.Entities.Customer;
//import com.qprogramming.smarttrainer.Managers.ClientManager;
//import com.qprogramming.smarttrainer.Util.DiskLruCacheAdapter;

import com.qprogramming.bookgeneration.AppEnv;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.HTTP;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONStringer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;

//import static com.qprogramming.smarttrainer.AppEnv.diskAdapter;

public class UpdateClientPhotoTask extends AsyncTask<String, Void, Boolean> {
    protected Boolean doInBackground(String... params) {
        String clientId = params[0];
        String path = params[1];
        Boolean result = false;
        try {
            HttpPost request = new HttpPost(AppEnv.url + "/UpdateClientPhoto");
            ;
            request.setHeader("Accept", "application/json");
            request.setHeader("Content-type", "application/json");

            JSONStringer vehicle = new JSONStringer()
                    .object()
                    .key("clientId").value(clientId)
                    .key("path").value(path)
                    .endObject();


            StringEntity entity = new StringEntity(vehicle.toString(), HTTP.UTF_8);
            request.setEntity(entity);

            // Send request to WCF service
            DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpResponse response = httpClient.execute(request);
            int code = response.getStatusLine().getStatusCode();
            if (code == 200) {
                result = true;
            }
            return true;
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return result;
    }
        @Override
    protected void onPostExecute(Boolean result) {
    }

}



