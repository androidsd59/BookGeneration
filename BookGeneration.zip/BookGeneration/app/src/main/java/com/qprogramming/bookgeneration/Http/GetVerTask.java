package com.qprogramming.bookgeneration.Http;

import android.os.AsyncTask;

//import com.qprogramming.smarttrainer.AppEnv;
//import com.qprogramming.smarttrainer.MainActivity;

import com.qprogramming.bookgeneration.AppEnv;
import com.qprogramming.bookgeneration.MainActivity;

import org.json.JSONException;
import org.json.JSONObject;

public class GetVerTask  extends AsyncTask<Integer, Void, Integer> {
    int current_verion = 0;
    protected Integer doInBackground(Integer... params) {
        Integer version_id = 0;
        current_verion = params[0];
        try {
            JSONParser jParser = new JSONParser();

            // getting JSON string from URL
            JSONObject json = jParser.getJSONFromUrl(AppEnv.url + "/GetVer");

            try {
                if(json != null)
                {
                    version_id = json.getInt("GetVerResult");
                }
            }
            catch (JSONException e) {
                e.printStackTrace();
            }
            return version_id;
        } catch (Exception e) {
            return version_id;
        }
    }

    @Override
    protected void onPostExecute(Integer version_number) {
        if(current_verion < version_number)
            // TODO  uncomment this operator
//            MainActivity.httpUtils.NotifyObservers("upgrade_app_version", "")
            ;
    }

}