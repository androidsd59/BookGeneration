package com.qprogramming.bookgeneration.Util;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Environment;
import android.util.Log;
import android.util.LruCache;



import com.jakewharton.disklrucache.DiskLruCache;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import static android.os.Environment.isExternalStorageRemovable;
/// https://www.programcreek.com/java-api-examples/?class=com.jakewharton.DiskLruCache&method=Snapshot
public class DiskLruCacheAdapter {
    private Context context;
    private static DiskLruCache diskLruCache;
    private static final Object diskCacheLock = new Object();
    private static boolean diskCacheStarting = true;
    private static final int DISK_CACHE_SIZE = 1024 * 1024 * 20; // 10MB
    private static final String DISK_CACHE_SUBDIR = "thumbnails";
    private static final int DISK_CACHE_INDEX = 0;
    private static LruCache<String, Bitmap> memoryCache;

    public void Init(Context context) {
        // Initialize memory cache
        // Initialize disk cache on background thread
        File cacheDir = getDiskCacheDir(context, DISK_CACHE_SUBDIR);
        this.context = context;
        memoryCache = new LruCache<String, Bitmap>(100);
        new InitDiskCacheTask().execute(cacheDir);
    }

    class InitDiskCacheTask extends AsyncTask<File, Void, Void> {
        @Override
        protected Void doInBackground(File... params) {
            synchronized (diskCacheLock) {
                File cacheDir = params[0];
                try {
                    diskLruCache = DiskLruCache.open(cacheDir, 1, 1, DISK_CACHE_SIZE);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                diskCacheStarting = false; // Finished initialization
                diskCacheLock.notifyAll(); // Wake any waiting threads
            }
            return null;
        }
    }

    class BitmapWorkerTask extends AsyncTask<Integer, Void, Bitmap> {
        // Decode image in background.
        @Override
        protected Bitmap doInBackground(Integer... params) {
            final String imageKey = String.valueOf(params[0]);

            // Check disk cache in background thread
            Bitmap bitmap = null;
            try {
                DiskLruCache.Snapshot snapshot = getBitmapFromDiskCache(imageKey);
                if(snapshot != null){
                    InputStream in = snapshot.getInputStream(0);
                    bitmap = BitmapFactory.decodeStream(in);
                    in.close();
                    snapshot.close();
                    snapshot = null;
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

            // Add final bitmap to caches
            try {
                addBitmapToCache(imageKey, bitmap);
            } catch (IOException e) {
                e.printStackTrace();
            }

            return bitmap;
        }
    }

    //Use this method to add the image to the disc and to the cache
    public void addBitmapToCache(String key, Bitmap bitmap) throws IOException {
        // Add to memory cache as before
        if (getBitmapFromMemCache(key) == null) {
            memoryCache.put(key, bitmap);
        }

        // Also add to disk cache
        synchronized (diskCacheLock) {
            if (diskLruCache != null && diskLruCache.get(key) == null) {
                final DiskLruCache.Editor editor = diskLruCache.edit(key);
                OutputStream out;
                if (editor != null) {
                    out = editor.newOutputStream(DISK_CACHE_INDEX);

                    bitmap.compress(Bitmap.CompressFormat.JPEG, 100, out);

                    editor.commit();
                    out.close();
                }
            }
        }
    }

    public DiskLruCache.Snapshot getBitmapFromDiskCache(String key) throws IOException {
        synchronized (diskCacheLock) {
            // Wait while disk cache is started from background thread
            while (diskCacheStarting) {
                try {
                    diskCacheLock.wait();
                } catch (InterruptedException e) {}
            }
            if (diskLruCache != null) {
                return diskLruCache.get(key);
            }
        }
        return null;
    }

    public Bitmap readFromDiskCache(String key){
        Bitmap bm = getBitmapFromMemCache(key);
        if(bm == null && diskLruCache != null){
            try {
                DiskLruCache.Snapshot snapshot = diskLruCache.get(key);
                if(snapshot != null){
                    InputStream in = snapshot.getInputStream(0);
                    bm = BitmapFactory.decodeStream(in);
                    in.close();
                    snapshot.close();
                    snapshot = null;
                    //Log.d(Constants.TAG_EMOP, "read from disk key:" + cacheKey + ", url:" + url.toString());
                }
            } catch (IOException e) {
                Log.e("IOException", "read disk lru cache error:" + e.toString());
            }
        }else {
            Log.e("IOException", "read disk lru cache is null");
        }

        return bm;
    }
    // Creates a unique subdirectory of the designated app cache directory. Tries to use external
    // but if not mounted, falls back on internal storage.
    public static File getDiskCacheDir(Context context, String uniqueName) {
        // Check if media is mounted or storage is built-in, if so, try and use external cache dir
        // otherwise use internal cache dir
        final String cachePath =
                Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState()) ||
                        !isExternalStorageRemovable() ? context.getExternalCacheDir().getPath() :
                        context.getCacheDir().getPath();

        return new File(cachePath + File.separator + uniqueName);
    }

    public boolean containsKey(String key) {

        boolean contained = false;
        DiskLruCache.Snapshot snapshot = null;
        try {
            snapshot = diskLruCache.get(key);
            contained = snapshot != null;
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (snapshot != null) {
                snapshot.close();
            }
        }

        return contained;

    }

    private void addBitmapToMemoryCache(String key, Bitmap bitmap) {
        if (getBitmapFromMemCache(key) == null) {
            memoryCache.put(key, bitmap);
        }
    }

    public Bitmap getBitmapFromMemCache(String key) {
        return memoryCache.get(key);
    }

}
