package com.qprogramming.bookgeneration

import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.View
import android.webkit.WebView
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.Response
import com.android.volley.VolleyError
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.qprogramming.bookgeneration.Http.GetLastRecordIdTask
import org.json.JSONException
import org.json.JSONObject
import retrofit2.http.Url

class AboutUsActivity : AppCompatActivity() {
    public val GLOBAL_STATUS_USER_REGISTRATION = 0
    public val GLOBAL_STATUS_USER_CREATED  = 1

    public final var btn_office_reg : Button? = null
//    var request_status_user : GetLastRecordIdTask? = null
    public final var myWebView : WebView? = null

    var json : String = " "
    var jObj: JSONObject? = null
    var val_btn_offreg = 1
    var global_status_user = 0

//    var strResponce = ""
    var isError = false
    var volleyError: VolleyError? = null
    var strUrl  = AppEnv.url + "getuser/123"
    var value_status_user = 0

    // address of server for request data about user   109.226.10.249/road/facade.svc/getuser/123

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about_us)

        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT

        btn_office_reg = findViewById(R.id.btn_office_registration)

//        if (val_btn_offreg == GLOBAL_STATUS_USER_REGISTER)
//            btn_office_reg?.setText(R.string.registration)
//        else
//            btn_office_reg?.setText(R.string.my_office)
        btn_office_reg?.setText("--------------")

        setTitle(R.string.about_us)

        myWebView = findViewById<WebView>(R.id.webView_film)
//      TODO  commented code plaing video-file
//        myWebView!!.getSettings().setLoadsImagesAutomatically(true);
//        myWebView!!.getSettings().setJavaScriptEnabled(true);
//        myWebView!!.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
//        myWebView!!.loadUrl("https://www.youtube.com/watch?v=1r9yolQSN1g" )//url);
//            progDailog = ProgressDialog.show(this, "Loading","Please wait...", true);
//            progDailog?.setCancelable(false);
//            //---
//            myWebView.getSettings().setJavaScriptEnabled(true);
//            myWebView.getSettings().setLoadWithOverviewMode(true);
//            myWebView.getSettings().setUseWideViewPort(true);
//            myWebView.setWebViewClient(
//                  //  WebViewClient() {
//                        //@Override
//                        fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
//                            progDailog.show();
//                            view.loadUrl(url);
//                            //---
//                            return true;
//                        }
//                        // ---
//                        //@Override
//                        fun onPageFinished(view: WebView, url: String) {
//                            progDailog?.dismiss();
//                        }
//                //    }
//            );
//            ---
//        var //videoView_film = findViewById(R.id.videoView_film)
//        videoView_film = VideoView(baseContext)
//        setContentView(videoView_film)
//        videoView_film.l loadUrl("https://www.youtube.com/")

        request_about_status_user()
    }

    fun setNameButtonRegisterMyOffice(value : Int) {
        if (value == GLOBAL_STATUS_USER_REGISTRATION) {
            btn_office_reg?.setText(R.string.registration)
            global_status_user = GLOBAL_STATUS_USER_REGISTRATION
        }
        else {
            btn_office_reg?.setText(R.string.my_office)
            global_status_user = GLOBAL_STATUS_USER_CREATED
        }
    }

    fun request_about_status_user() {
        var strResponce = ""
        var isError = false
        var volleyError: VolleyError? = null
        var strUrl  = AppEnv.url + "getuser/123"
        var value_status_user = 0

        // Instantiate the RequestQueue.
        val queue: RequestQueue =  Volley.newRequestQueue(baseContext) // getApplicationContext());
        //        var json = ""
        // Request a string response from the provided URL.
        val stringRequest = StringRequest(
            Request.Method.GET,
            //AppEnv.url + "getuser/123",  // url,
            strUrl,
            { response: String -> // Display the first 500 characters of the response string.
                strResponce = response

                try {
                    json = strResponce //sb.toString();//here json type is string
                 //   json = response.substring(0, 500)
                }
                catch (e: Exception) {
                    Log.e("Buffer Error", "Error converting result " + e.toString());
                }
                try {
                    jObj = JSONObject (json);
                    var userResult : JSONObject? = null
                    userResult = jObj!!.getJSONObject("GetUserResult")
                    value_status_user = userResult.getInt("Status")
                    setNameButtonRegisterMyOffice(value_status_user)
                }
                catch (e : JSONException) {
                    Log.e("JSON Parser For Parser", "Error parsing data " + e.toString());
                }
            },
            { error -> //textView.setText("That didn't work!");
                volleyError = error
                isError = true
            }
        )

        // Add the request to the RequestQueue.
        queue.add(stringRequest)

    }

    fun onClickBtnRegisterMyOffice(view : View) {
        if (global_status_user == GLOBAL_STATUS_USER_REGISTRATION)
        {
            val intent_my_office = Intent(this, RegistrationActivity::class.java);
            startActivity(intent_my_office)
        }
        else
        {   //  GLOBAL_STATUS_USER_CREATED
            val intent_my_office = Intent(this, MyOfficeActivity::class.java);
            startActivity(intent_my_office)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        var inflater = getMenuInflater();
        inflater.inflate(R.menu.about_as_menu, menu)

        return super.onCreateOptionsMenu(menu)
    }
}