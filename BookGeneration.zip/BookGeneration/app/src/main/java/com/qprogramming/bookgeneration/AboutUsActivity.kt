package com.qprogramming.bookgeneration

import android.content.Intent
import android.content.pm.ActivityInfo
import android.media.MediaPlayer
import android.media.MediaPlayer.OnCompletionListener
import android.media.MediaPlayer.OnPreparedListener
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PersistableBundle
import android.util.Log
import android.view.Menu
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.webkit.URLUtil
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.VolleyError
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.lang.IllegalArgumentException
import kotlin.time.minutes


class AboutUsActivity : AppCompatActivity(),  SurfaceHolder.Callback, OnPreparedListener {
    public val GLOBAL_STATUS_USER_REGISTRATION = 0
    public val GLOBAL_STATUS_USER_CREATED  = 1
    val TAG = "IllegalArgExc"

    public final var btn_office_reg : Button? = null
    public final var progressBar : ProgressBar? = null
    //progressBar_about_us
    private var videoView_film : VideoView? = null
    // Current playback position (in milliseconds).
    private var mCurrentPosition = 0
    // Tag for the instance state bundle.
    private val PLAYBACK_TIME = "play_time"
    // Use this string for part 2 (load media from the internet).
    //val videoSource = "http://109.226.10.249/road/1.mp4"
    public val VIDEO_SAMPLE = "http://109.226.10.249/road/1.mp4"
    var controller : MediaController? = null
    var mediaPlayer : MediaPlayer? = null

    var json : String = " "
    var jObj: JSONObject? = null
    var val_btn_offreg = 1
    var global_status_user = 0

//    var strResponce = ""
    var isError = false
    var volleyError: VolleyError? = null
    var strUrl  = AppEnv.url + "getuser/123"
    var value_status_user = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about_us)

        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT

        btn_office_reg = findViewById(R.id.btn_office_registration)

//        if (val_btn_offreg == GLOBAL_STATUS_USER_REGISTER)
//            btn_office_reg?.setText(R.string.registration)
//        else
//            btn_office_reg?.setText(R.string.my_office)
        btn_office_reg?.setText("--------------")

        setTitle(R.string.about_us)


//      TODO  commented code plaing video-file
        videoView_film = findViewById<View>(R.id.videoView_film) as VideoView
        mediaPlayer = MediaPlayer()

        if (savedInstanceState != null) {
            mCurrentPosition = savedInstanceState.getInt(PLAYBACK_TIME)
        }

        // Set up the media controller widget and attach it to the video view.
        startShowVideoView()

        request_about_status_user()
    }
    //_________________________________________________________________________

    fun startShowVideoView(){
//        if (controller != null) {
//            controller = null
//        }
//        // Set up the media controller widget and attach it to the video view.
//        controller = MediaController(this)
//        // set the anchor view for the video view
//        controller!!.setAnchorView(this.videoView_film)
//        controller!!.setMediaPlayer(videoView_film)
//        videoView_film!!.setMediaController(controller)
//        videoView_film!!.requestFocus()
//        //controller!!

//        var surfaceView = findViewById<SurfaceView>(R.id.surfaceView)
//        surfaceView.setKeepScreenOn(true)

//        var holder : SurfaceHolder = surfaceView.getHolder()
//        holder.addCallback(this)
//        holder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS)
//        holder.setFixedSize(400, 300)

//        // Button Play
//        var playBtn = findViewById<Button>(R.id.btn_media_play)
//        playBtn.setOnClickListener { onClickListener -> {
//            fun onClick(view: View) {mediaPlayer!!.start()}
//        } }
//
//        // Button Play
//        var pauseBtn = findViewById<Button>(R.id.btn_media_pause)
//        playBtn.setOnClickListener { onClickListener -> {
//            fun onClick(view: View) {mediaPlayer!!.stop()}
//        } }
//
//        // Button Next or Skip
//        var skipBtn = findViewById<Button>(R.id.btn_media_skip)
//        playBtn.setOnClickListener { onClickListener -> {
//            fun onClick(view: View) {mediaPlayer!!.seekTo(mediaPlayer!!.duration/2)}
//        } }
    }
    //_________________________________________________________________________

    override fun onStart() {
        super.onStart()

        // Load the media each time onStart() is called.
        initializePlayer();
    }
    //_________________________________________________________________________

    override fun onPause() {
        super.onPause()

        // In Android versions less than N (7.0, API 24), onPause() is the
        // end of the visual lifecycle of the app.  Pausing the video here
        // prevents the sound from continuing to play even after the app
        // disappears.
        //
        // This is not a problem for more recent versions of Android because
        // onStop() is now the end of the visual lifecycle, and that is where
        // most of the app teardown should take place.
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
            videoView_film!!.pause();
        }
    }
    //_________________________________________________________________________

    override fun onStop() {
        super.onStop()

        // Media playback takes a lot of resources, so everything should be
        // stopped and released at this time.
        releasePlayer();
    }
    //_________________________________________________________________________

    override fun onSaveInstanceState(outState: Bundle, outPersistentState: PersistableBundle) {
        super.onSaveInstanceState(outState, outPersistentState)

        // Save the current playback position (in milliseconds) to the
        // instance state bundle.
        outState.putInt(PLAYBACK_TIME, videoView_film!!.getCurrentPosition());

    }
    //_________________________________________________________________________

    private fun initializePlayer() {
        // Show the "Buffering..." message while the video loads.
//        mBufferingTextView.setVisibility(VideoView.VISIBLE)

        // Buffer and decode the video sample.
        val videoUri: Uri = getMedia(VIDEO_SAMPLE)
        videoView_film!!.setVideoURI(videoUri)

        // Listener for onPrepared() event (runs after the media is prepared).
        videoView_film!!.setOnPreparedListener(
            OnPreparedListener { // Hide buffering message.
//                mBufferingTextView.setVisibility(VideoView.INVISIBLE)

                // Restore saved position, if available.
                if (mCurrentPosition > 0) {
                    videoView_film!!.seekTo(mCurrentPosition)
                } else {
                    // Skipping to 1 shows the first frame of the video.
                    videoView_film!!.seekTo(1)
                }

                // Start playing!
                videoView_film!!.start()
            })

        // Listener for onCompletion() event (runs after media has finished
        // playing).
        videoView_film!!.setOnCompletionListener(
            OnCompletionListener {
                Toast.makeText(
                    this,
                    "Play message"//R.string.toast_message
                    ,//Toast.LENGTH_SHORT
                    Toast.LENGTH_LONG
                ).show()

                // Return the video position to the start.
                videoView_film!!.seekTo(0)
            })
    }
    //_________________________________________________________________________

    // Release all media-related resources. In a more complicated app this
    // might involve unregistering listeners or releasing audio focus.
    private fun releasePlayer() {
        videoView_film!!.stopPlayback()
    }
    //_________________________________________________________________________

    // Get a Uri for the media sample regardless of whether that sample is
    // embedded in the app resources or available on the internet.
    private fun getMedia(mediaName: String): Uri {
        return if (URLUtil.isValidUrl(mediaName)) {
            // Media name is an external URL.
            Uri.parse(mediaName)
        } else {
            // Media name is a raw resource embedded in the app.
            Uri.parse(
                "android.resource://" + packageName +
                        "/raw/" + mediaName
            )
        }
    }
    //_________________________________________________________________________

    fun onClickStartVideoViewFilm(view: View){
        releasePlayer()
        startShowVideoView()
        initializePlayer()
    }
    //_________________________________________________________________________

    fun onClickStopVideoViewFilm(view: View) {
        videoView_film!!.stopPlayback()
    }
    //_________________________________________________________________________

    //==============================================================================================
    //==============================================================================================

    fun setNameButtonRegisterMyOffice(value: Int) {
        if (value == GLOBAL_STATUS_USER_REGISTRATION) {
            btn_office_reg?.setText(R.string.registration)
            global_status_user = GLOBAL_STATUS_USER_REGISTRATION
        }
        else {
            btn_office_reg?.setText(R.string.my_office)
            global_status_user = GLOBAL_STATUS_USER_CREATED
        }
    }
    //_________________________________________________________________________

    fun request_about_status_user() {
        var strResponce = ""
        var isError = false
        var volleyError: VolleyError? = null
        var strUrl  = AppEnv.url + "getuser/123"
        var value_status_user = 0

        // Instantiate the RequestQueue.
        val queue: RequestQueue =  Volley.newRequestQueue(baseContext) // getApplicationContext());

        // Request a string response from the provided URL.
        val stringRequest = StringRequest(
            Request.Method.GET,
            strUrl,
            { response: String -> // Display the first 500 characters of the response string.
                strResponce = response

                try {
                    json = strResponce //sb.toString();//here json type is string
                    //   json = response.substring(0, 500)
                } catch (e: Exception) {
                    Log.e("Buffer Error", "Error converting result " + e.toString());
                }
                try {
                    jObj = JSONObject(json);
                    var userResult: JSONObject? = null
                    userResult = jObj!!.getJSONObject("GetUserResult")
                    value_status_user = userResult.getInt("Status")
                    setNameButtonRegisterMyOffice(value_status_user)
                } catch (e: JSONException) {
                    Log.e("JSON Parser For Parser", "Error parsing data " + e.toString());
                }
            },
            { error -> //textView.setText("That didn't work!");
                volleyError = error
                isError = true
            }
        )

        // Add the request to the RequestQueue.
        queue.add(stringRequest)
    }
    //_________________________________________________________________________

    fun onClickBtnRegisterMyOffice(view: View) {
        if (global_status_user == GLOBAL_STATUS_USER_REGISTRATION)
        {
            val intent_my_office = Intent(this, RegistrationActivity::class.java);
            startActivity(intent_my_office)
        }
        else
        {   //  GLOBAL_STATUS_USER_CREATED
            val intent_my_office = Intent(this, MyOfficeActivity::class.java);
            startActivity(intent_my_office)
        }
    }
    //_________________________________________________________________________

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        var inflater = getMenuInflater();
        inflater.inflate(R.menu.about_as_menu, menu)

        return super.onCreateOptionsMenu(menu)
    }
    //_________________________________________________________________________

    fun onClickBtnSearchDeceased(view: View) {
        val intent_search_deceased = Intent(this, SearchDeceasedActivity::class.java);
        startActivity(intent_search_deceased)
    }
    //_________________________________________________________________________

    companion object {
        // Release all media-related resources. In a more complicated app this
        // might involve unregistering listeners or releasing audio focus.
        private fun releasePlayer(aboutUsActivity: AboutUsActivity) {
            aboutUsActivity.videoView_film!!.stopPlayback()
        }
    }
    //_________________________________________________________________________


    //==============================================================================================
    //
    //      --------------------------------  SurfaceHolder  --------------------------------
    //
    //==============================================================================================
    override fun surfaceCreated(holder: SurfaceHolder) {
        try {
            mediaPlayer!!.setDisplay(holder)
            mediaPlayer!!.setDataSource(VIDEO_SAMPLE)
            mediaPlayer!!.prepare()
        }
        catch (e : IllegalArgumentException)
        {
            Log.d(TAG, "Illegal Argument Exception" + e)
        }
        catch (e : IllegalStateException)
        {
            Log.d(TAG, "Illegal State Exception" + e)
        }
        catch (e : SecurityException)
        {
            Log.d(TAG, "Security Exception" + e)
        }
        catch (e : IOException)
        {
            Log.d(TAG, "IO Exception" + e)
        }
    }
    //_________________________________________________________________________

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        mediaPlayer!!.release()
    }
    //_________________________________________________________________________

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        TODO("Not yet implemented")
    }
    //_________________________________________________________________________

    override fun onPrepared(mp: MediaPlayer?) {
        TODO("Not yet implemented")
    }
    //_________________________________________________________________________
}