package com.qprogramming.bookgeneration

import android.app.DatePickerDialog
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.icu.util.GregorianCalendar
import android.icu.util.HebrewCalendar
import android.icu.util.ULocale
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.*
import android.widget.AdapterView.OnItemClickListener
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.VolleyError
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONException
import org.json.JSONObject
import java.util.*


class SearchDeceasedActivity : AppCompatActivity() {
    var constants = Constants()

    var json : String = " "
    var jObj: JSONObject? = null
    var localLenguage : Int = 0

    //var HebrewCalendar обычно следует создавать, Calendar.getInstance(ULocale)передавая ULocale с тегом "@calendar=hebrew".
    lateinit var calendarHebrew : HebrewCalendar
    lateinit var calendarGergorian : GregorianCalendar
//    var calendarSearchDec : CalendarView? = null
//    var calendar : HebrewCalendar? = null
    var hebrewCalendar : HebrewCalendar? = null
    var button_select_date : Button? = null
    var text_show_Date : TextView? = null

    var listViewCountries : ListView? = null
    var arrayCountries: ArrayList<String> = arrayListOf()
    val TAG = "SearchDeceased :"

    private var sPref: SharedPreferences? = null

    var type_language = constants.TYPE_LANGUAGE_NOT_SELECTED

    var selectedCountryText = ""
    var selectedCountryIndex = -1

    var textSelectedCountry : TextView? = null


    @RequiresApi(Build.VERSION_CODES.N)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search_deceased)
        setSupportActionBar(findViewById(R.id.toolbar))

        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        setTitle(R.string.search_for_deceased)

        textSelectedCountry = findViewById(R.id.textView_SelectedCountry_label)

//        calendarSearchDec  = findViewById(R.id.calendarView_SearchDeceased)
        //calendar = HebrewCalendar()
        hebrewCalendar = HebrewCalendar()
        button_select_date = findViewById(R.id.btn_calendarView_SearchDeceased)
        text_show_Date = findViewById(R.id.textView_FromToDateDeathSearch_label)

        sPref = getSharedPreferences("MyPref", MODE_PRIVATE)
        loadTypeLang()

        listViewCountries = findViewById<ListView>(R.id.listView_Country)
        requestAboutCountry()

        createButtonSelectDate()

//        TODO  uncomment if must be send email
//        findViewById<FloatingActionButton>(R.id.fab).setOnClickListener { view ->
//            Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                    .setAction("Action", null).show()
//        }
    }
    //_________________________________________________________________________

    @RequiresApi(Build.VERSION_CODES.N)
    private fun loadTypeLang() {
        type_language = sPref?.getInt(constants.TYPE_LANG, constants.TYPE_LANGUAGE_NOT_SELECTED) ?: constants.TYPE_LANGUAGE_NOT_SELECTED

        if (type_language == constants.TYPE_LANGUAGE_HEBREW) {

            controlDataHebrewCalendar()

//            hebrewCalendar!!.roll(Calendar. DATE, 9)

//            controlDataHebrewCalendar()
        }
    }
    //_________________________________________________________________________

    @RequiresApi(Build.VERSION_CODES.N)
    fun createButtonSelectDate(){

        val c = Calendar.getInstance()
        val year = c.get(Calendar.YEAR)
        val month = c.get(Calendar.MONTH)
        val day = c.get(Calendar.DAY_OF_MONTH)

        val yearHebrew = hebrewCalendar!!.get(HebrewCalendar.YEAR )
        val dayHebrew = hebrewCalendar!!.get(HebrewCalendar.DAY_OF_MONTH )
        val monthHebrew = hebrewCalendar!!.get(HebrewCalendar.MONTH )
        val ampmHebrew = hebrewCalendar!!.get(HebrewCalendar.AM_PM )

        button_select_date!!.setOnClickListener{
            val dpd = DatePickerDialog(this,
                DatePickerDialog.OnDateSetListener { view, mYear, mMonth, mDay ->

                    val strAmPm = getNameParameterHebrewCalendarAMPM(ampmHebrew)
                    val strMonthHebrew = getNameMonthHebrewCalendar(monthHebrew)
                    text_show_Date!!.setText("   " + dayHebrew + "   " + strMonthHebrew + "    " + yearHebrew + "  " + strAmPm)
                }, year, month, day)
                //},  yearHebrew, monthHebrew, dayHebrew)

                    dpd.show()
        }

    }
    //_________________________________________________________________________

    fun getNameParameterHebrewCalendarAMPM(number : Int) : String {

        when (number) {
            0 -> return "AM"
            else -> return "PM"
        }
    }
    //_________________________________________________________________________

    fun getNameMonthHebrewCalendar(number : Int) : String {

        when (number) {
            0 ->    return "TISHRI"
            1 ->    return "HESHVAN"
            2 ->    return "KISLEV"
            3 ->    return "TEVET"
            4 ->    return "SHEVAT"
            5 ->    return "ADAR_1"
            6 ->    return "АДАР"
            7 ->    return "NISAN"
            8 ->    return "IYAR"
            9 ->    return "SIVAN"
            10 ->    return "TAMUZ"
            11 ->    return "AV"
            12 ->    return "ELUL"

            else ->     return " ? "
        }
    }
    //_________________________________________________________________________

    fun controlDataHebrewCalendar() {

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {

        } else {
            TODO("VERSION.SDK_INT < N")
        }
    }
    //_________________________________________________________________________

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        var inflater = getMenuInflater();
        inflater.inflate(R.menu.search_deceased_menu, menu)

        return super.onCreateOptionsMenu(menu)
    }
    //_________________________________________________________________________

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        var id = item.itemId

        if (id == R.id.search_deceased_menu_1)
        {
            val intent_my_office = Intent(this, SearchDeceasedResultActivity::class.java);
            startActivity(intent_my_office)
        }

        return super.onOptionsItemSelected(item)
    }
    //_________________________________________________________________________

    fun requestAboutCountry() {
        var strResponce = ""
        var isError = false
        var volleyError: VolleyError? = null

        var strUrl  = AppEnv.url + "/Getcountries/" + type_language.toString()
        var value_status_user = 0

        // Instantiate the RequestQueue.
        val queue: RequestQueue =  Volley.newRequestQueue(baseContext) // getApplicationContext());

        // Request a string response from the provided URL.
        val stringRequest = StringRequest(
                Request.Method.GET,
                strUrl,
                { response: String -> // Display the first 500 characters of the response string.
                    strResponce = response

                    try {
                        json = strResponce
                    } catch (e: Exception) {
                        Log.e(TAG, "Buffer Error converting result " + e.toString());
                    }
                    try {
                        jObj = JSONObject(json);

                        unPackAndShowCountriesFromServer(jObj!!)
                    } catch (e: JSONException) {
                        Log.e(TAG, "JSON Parser For Parser Error parsing data " + e.toString());
                    }
                },
                { error -> //textView.setText("That didn't work!");
                    volleyError = error
                    isError = true
                }
        )

        // Add the request to the RequestQueue.
        queue.add(stringRequest)
    }
    //_________________________________________________________________________

    fun unPackAndShowCountriesFromServer(jsonObj: JSONObject){
        try {
            var inputArray = jsonObj!!.getJSONArray("GetCountriesResult")

            var arrayCountriesCodes: ArrayList<String>? = arrayListOf()

            var lenCountriesCodes: Int = inputArray.length()
            for (i in 0 until lenCountriesCodes) {
                var objectsCountriesCodes : String = inputArray.getString(i)
                arrayCountriesCodes!!.add(objectsCountriesCodes)

                var objectCountryCodes : JSONObject? = null
                objectCountryCodes = JSONObject(objectsCountriesCodes)

                var country : String = objectCountryCodes.getString("Name")
                arrayCountries!!.add(country)
            }

        }
        catch (e: JSONException)
        {
            Log.d("Error unpackCountr", e.toString())
        }

        // Create adapters
        val adapterCountries: ArrayAdapter<String>
        adapterCountries = ArrayAdapter<String>(
                this,
                android.R.layout.simple_list_item_1,
                arrayCountries
        )
        listViewCountries!!.setAdapter(adapterCountries)
        listViewCountries!!.setOnItemClickListener(OnItemClickListener { parent, itemClicked, position, id ->
            //var dialog = ObjectSelectionDialogFragment()
            //dialog.showsDialog

            selectedCountryText = adapterCountries.getItem(position).toString()
            selectedCountryIndex = position

            textSelectedCountry!!.text = "    " + selectedCountryText.toString()
            textSelectedCountry!!.setBackgroundColor(Color.GREEN)
//            textSelectedCountry!!.visibility = View.VISIBLE
        })
    }
    //_________________________________________________________________________

//    override fun onCreateDialog(id: Int): Dialog {
//        return super.onCreateDialog(id)
//    }

//    override fun onCreateDialog(id: Int, args: Bundle?): Dialog? {
//        return super.onCreateDialog(id, args)
//        //val builder: AlertDialog.Builder = AlertDialog.Builder(getActivity(this, 0, intent, FLAG_ONE_SHOT))
//        var builder: AlertDialog.Builder = AlertDialog.Builder(this)
//        //builder.setTitle(R.string.pick_color)
//        builder.setTitle(R.string.country)
//            //.setItems(R.array.colors_array, object : DialogInterface.OnClickListener() {
//            .setItems(arrayCountries.size,
//                OnClickListener { dialog, which ->
//                    // The 'which' argument contains the index position
//                    // of the selected item
//                })
//        return builder.create()
//    }
}