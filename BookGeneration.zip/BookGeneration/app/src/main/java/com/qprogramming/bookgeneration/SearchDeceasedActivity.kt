package com.qprogramming.bookgeneration

import android.app.AlertDialog
import android.app.Dialog
import android.app.PendingIntent.FLAG_ONE_SHOT
import android.app.PendingIntent.getActivity
import android.content.DialogInterface
import android.content.DialogInterface.OnClickListener
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.AdapterView.OnItemClickListener
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.get
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.VolleyError
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONException
import org.json.JSONObject
import java.util.*


class SearchDeceasedActivity : AppCompatActivity() {
    var constants = Constants()

    var json : String = " "
    var jObj: JSONObject? = null
    var localLenguage : Int = 0

    var listViewCountries : ListView? = null
    var arrayCountries: ArrayList<String> = arrayListOf()
    val TAG = "SearchDeceased :"

    private var sPref: SharedPreferences? = null

    var type_language = constants.TYPE_LANGUAGE_NOT_SELECTED

    var selectedCountryText = ""
    var selectedCountryIndex = -1

    var textSelectedCountry : TextView? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search_deceased)
        setSupportActionBar(findViewById(R.id.toolbar))

        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        setTitle(R.string.search_for_deceased)

        textSelectedCountry = findViewById(R.id.textView_SelectedCountry_label)

        sPref = getSharedPreferences("MyPref", MODE_PRIVATE)
        loadTypeLang()

        listViewCountries = findViewById<ListView>(R.id.listView_Country)
        requestAboutCountry()

//        TODO  uncomment if must be send email
//        findViewById<FloatingActionButton>(R.id.fab).setOnClickListener { view ->
//            Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                    .setAction("Action", null).show()
//        }
    }
    //_________________________________________________________________________

    private fun loadTypeLang() {
        type_language = sPref?.getInt(constants.TYPE_LANG, constants.TYPE_LANGUAGE_NOT_SELECTED) ?: constants.TYPE_LANGUAGE_NOT_SELECTED
    }
    //_________________________________________________________________________

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        var inflater = getMenuInflater();
        inflater.inflate(R.menu.search_deceased_menu, menu)

        return super.onCreateOptionsMenu(menu)
    }
    //_________________________________________________________________________

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        var id = item.itemId

        if (id == R.id.search_deceased_menu_1)
        {
            val intent_my_office = Intent(this, SearchDeceasedResultActivity::class.java);
            startActivity(intent_my_office)
        }

        return super.onOptionsItemSelected(item)
    }
    //_________________________________________________________________________

    fun requestAboutCountry() {
        var strResponce = ""
        var isError = false
        var volleyError: VolleyError? = null

        var strUrl  = AppEnv.url + "/Getcountries/" + type_language.toString()
        var value_status_user = 0

        // Instantiate the RequestQueue.
        val queue: RequestQueue =  Volley.newRequestQueue(baseContext) // getApplicationContext());

        // Request a string response from the provided URL.
        val stringRequest = StringRequest(
            Request.Method.GET,
            strUrl,
            { response: String -> // Display the first 500 characters of the response string.
                strResponce = response

                try {
                    json = strResponce
                } catch (e: Exception) {
                    Log.e(TAG, "Buffer Error converting result " + e.toString());
                }
                try {
                    jObj = JSONObject(json);

                    unPackAndShowCountriesFromServer(jObj!!)
                } catch (e: JSONException) {
                    Log.e(TAG, "JSON Parser For Parser Error parsing data " + e.toString());
                }
            },
            { error -> //textView.setText("That didn't work!");
                volleyError = error
                isError = true
            }
        )

        // Add the request to the RequestQueue.
        queue.add(stringRequest)
    }
    //_________________________________________________________________________

    fun unPackAndShowCountriesFromServer(jsonObj: JSONObject){
        try {
            var inputArray = jsonObj!!.getJSONArray("GetCountriesResult")

            var arrayCountriesCodes: ArrayList<String>? = arrayListOf()

            var lenCountriesCodes: Int = inputArray.length()
            for (i in 0 until lenCountriesCodes) {
                var objectsCountriesCodes : String = inputArray.getString(i)
                arrayCountriesCodes!!.add(objectsCountriesCodes)

                var objectCountryCodes : JSONObject? = null
                objectCountryCodes = JSONObject(objectsCountriesCodes)

                var country : String = objectCountryCodes.getString("Name")
                arrayCountries!!.add(country)
            }

        }
        catch (e: JSONException)
        {
            Log.d("Error unpackCountr", e.toString())
        }

        // Create adapters
        val adapterCountries: ArrayAdapter<String>
        adapterCountries = ArrayAdapter<String>(
            this,
            android.R.layout.simple_list_item_1,
            arrayCountries
        )
        listViewCountries!!.setAdapter(adapterCountries)
        listViewCountries!!.setOnItemClickListener(OnItemClickListener { parent, itemClicked, position, id ->
            //var dialog = ObjectSelectionDialogFragment()
            //dialog.showsDialog

            selectedCountryText = adapterCountries.getItem(position).toString()
            selectedCountryIndex = position

            textSelectedCountry!!.text = "    " + selectedCountryText.toString()
            textSelectedCountry!!.setBackgroundColor(Color.GREEN)
//            textSelectedCountry!!.visibility = View.VISIBLE
        })
    }
    //_________________________________________________________________________

//    override fun onCreateDialog(id: Int): Dialog {
//        return super.onCreateDialog(id)
//    }

//    override fun onCreateDialog(id: Int, args: Bundle?): Dialog? {
//        return super.onCreateDialog(id, args)
//        //val builder: AlertDialog.Builder = AlertDialog.Builder(getActivity(this, 0, intent, FLAG_ONE_SHOT))
//        var builder: AlertDialog.Builder = AlertDialog.Builder(this)
//        //builder.setTitle(R.string.pick_color)
//        builder.setTitle(R.string.country)
//            //.setItems(R.array.colors_array, object : DialogInterface.OnClickListener() {
//            .setItems(arrayCountries.size,
//                OnClickListener { dialog, which ->
//                    // The 'which' argument contains the index position
//                    // of the selected item
//                })
//        return builder.create()
//    }
}