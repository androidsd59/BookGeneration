package com.qprogramming.bookgeneration.Managers;

import android.util.Log;

import com.qprogramming.bookgeneration.AppEnv;
import com.qprogramming.bookgeneration.DB.PersonalData;
import com.qprogramming.bookgeneration.Entities.Customer;
import com.qprogramming.bookgeneration.MyFirebaseInstanceIDService;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.HTTP;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONStringer;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

public class ClientManager {

    public Customer GetClient(String xml)
    {
        Customer client = new Customer();
        StringReader stream = new StringReader(xml);
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db;
            db = dbf.newDocumentBuilder();

            org.w3c.dom.Document doc = null;
            try {
                doc = db.parse(new InputSource(stream));
                doc.getDocumentElement().normalize();
                NodeList nodeList = doc.getElementsByTagName("client");

                for(int counter = 0; counter < nodeList.item(0).getAttributes().getLength(); ++counter)
                {
                    String attr = nodeList.item(0).getAttributes().item(counter).getNodeName();
                    if(attr.equals("id"))
                        client.setClientId(Integer.parseInt(nodeList.item(0).getAttributes().item(counter).getTextContent()));
                }
            } catch (SAXException e) {
                Log.d ("Get Client", "Get client error=[" + e.getMessage() + "]");
            } catch (IOException e) {}
        } catch (ParserConfigurationException e1) {}
        return client;
    }

    public Customer GetClient()
    {
        PersonalData dal = new PersonalData();
        Customer client = dal.readData();
        if(client.getClientId() > 0)
        {
            // TODO  create    TrainingDayManager dayManager = new TrainingDayManager();
//            TrainingDayManager dayManager = new TrainingDayManager();
//            client.setTrainingDays(dayManager.read());
        }
        return client;
    }

    public long insert(Customer client) throws Exception
    {
        PersonalData dal = new PersonalData();
        if(AppEnv.Personal.getToken().length() == 0) {
            MyFirebaseInstanceIDService myFirebaseInstanceIDService = new MyFirebaseInstanceIDService();
            AppEnv.Personal.setToken(myFirebaseInstanceIDService.getToken());
        }
        long clientId = dal.insert(client.getFirstName(), client.getLastName(), client.getTelephone(), client.getEmail(), client.getCreditCardNumber(), client.getCreditCardExpDate(),
                client.getCreditCardCVV(), client.getAge(),client.getWeight(),client.getHeight(),client.getMyGoal(),client.getPhysicalCondition(), client.getSex(),
                1);

        // TODO  create    TrainingDayManager dayManager = new TrainingDayManager();
//        TrainingDayManager dayManager = new TrainingDayManager();
//        dayManager.insert(client.getTrainingDays());

        return clientId;
    }

    public void apply(Customer client) throws Exception {
        PersonalData dal = new PersonalData();
        dal.apply(client.getFirstName(), client.getLastName(), client.getTelephone(), client.getEmail(), client.getCreditCardNumber(), client.getCreditCardExpDate(),
                client.getCreditCardCVV(), client.getAge(),client.getWeight(),client.getHeight(),client.getMyGoal(),client.getPhysicalCondition(), client.getSex(),1);

        // TODO  create    TrainingDayManager dayManager = new TrainingDayManager();
//        TrainingDayManager dayManager = new TrainingDayManager();
//        dayManager.insert(client.getTrainingDays());
    }

    public void update_record_id(int record_id)
    {
        PersonalData dal = new PersonalData();
        dal.update_record_id(record_id);
    }
    public void update_client_id(int client_id)
    {
        PersonalData dal = new PersonalData();
        dal.update_client_id(client_id);
    }

    public Customer send(Customer customer)
    {
        try {
            HttpPost request = null;
            if(customer.getClientId() == 0)
                request = new HttpPost(AppEnv.url + "/AddClient");
            else
                request = new HttpPost(AppEnv.url + "/UpdateClient");
            request.setHeader("Accept", "application/json");
            request.setHeader("Content-type", "application/json");

            JSONStringer vehicle = new JSONStringer()
                    .object()
                        .key("client")
                            .object()
                                .key("ClientId").value(customer.getClientId())
                                .key("FirstName").value(customer.getFirstName())
                                .key("LastName").value(customer.getLastName())
                                .key("MobilePhone").value(customer.getTelephone())
                                .key("Email").value(customer.getEmail())
                                .key("CardNumber").value(customer.getCreditCardNumber())
                                .key("CardCVV").value(customer.getCreditCardCVV())
                                .key("CardExpired").value(customer.getCreditCardExpDate())
                                .key("Age").value(customer.getAge())
                                .key("Height").value(customer.getHeight())
                                .key("Weight").value(customer.getWeight())
                                .key("MyGoal").value(customer.getMyGoal())
                                .key("PhysicalCondition").value(customer.getPhysicalCondition())
                                .key("Token").value(customer.getToken())
                                .key("Adv").value("1")
                            .key("TrainingDays")
                                .array()
                                    .object()
                                        .key("ClientId").value(customer.getClientId())
                                        .key("DayType").value(customer.getClientId())
                                        .key("Duration").value(customer.getClientId())
                                    .endObject()
                                    .object()
                                        .key("ClientId").value(customer.getClientId())
                                        .key("DayType").value(customer.getClientId())
                                        .key("Duration").value(customer.getClientId())
                                    .endObject()
                                .endArray()
                        .endObject()
                    .endObject();

            StringEntity entity = new StringEntity(vehicle.toString(), HTTP.UTF_8);
            request.setEntity(entity);

            // Send request to WCF service
            DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpResponse response = httpClient.execute(request);
            int code = response.getStatusLine().getStatusCode();
            if(code == 200)
            {
                BufferedReader reader = new BufferedReader(new InputStreamReader(response.getEntity().getContent(), "UTF-8"));
                String json = reader.readLine();
                try {
                    JSONObject jObj = new JSONObject(json);
                    if(customer.getClientId() == 0)
                        customer.setClientId(jObj.getInt("AddClientResult"));
                } catch (JSONException e) {
                    Log.e("JSON Client Parser", "Error parsing data " + e.toString());
                }
            }

            return customer;
        } catch (Exception e) {
            Log.e("Send client", "Error " + e.toString());
            return null;
        }
    }
}