package com.qprogramming.bookgeneration;

import android.app.ActionBar;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Fragment;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.TabHost;
import android.widget.TextView;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.navigation.NavigationView;
import com.qprogramming.bookgeneration.Entities.Message;
import com.qprogramming.bookgeneration.Http.APdu;
import com.qprogramming.bookgeneration.Http.GetVerTask;
import com.qprogramming.bookgeneration.Http.HttpUtils;
//import com.qprogramming.bookgeneration.Screens.Activities.Profile;
//import com.qprogramming.bookgeneration.Screens.Activities.RegisterActivity;

import java.util.Observable;
import java.util.Observer;

//import io.reactivex.android.schedulers.AndroidSchedulers;
//import io.reactivex.schedulers.Schedulers;

public class OtherMainActivity // extends AppCompatActivity implements Observer, AppResultReceiver.Receiver, NavigationView.OnNavigationItemSelectedListener
{

    //Fragment fragmentMuscleGroups = new MuscleGroups();

    Menu menu;
    AlertDialog dialog;
    int unreadable_messages;
    MenuItem item_main_menu;
    ActionBar.TabListener tab;
    TabHost mTabHost;
    ViewPager viewPager;


    public static HttpUtils httpUtils = new HttpUtils();
    public static boolean running_as_service = true;
    public static Activity activity;
    public static ActionBar actionBar;

    //  TODO   uncomment body of this class
/***************************************************************************************************

    public AppResultReceiver mReceiver;

    @Override
    protected void onStart() {
        super.onStart();

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);
        setContentView(R.layout.activity_main_tabs_manager);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close){
            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {

                try{
                    InputMethodManager inputMethodManager = (InputMethodManager)
                            getSystemService(Activity.INPUT_METHOD_SERVICE);
                    inputMethodManager.hideSoftInputFromWindow(
                            getCurrentFocus().getWindowToken(),
                            0
                    );

                }catch (Exception e){


                }
            }
        };
        drawer.addDrawerListener(toggle);
        toggle.syncState();



        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        activity = this;

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        running_as_service = false;
        httpUtils.addObserver(this);

        com.qprogramming.bookgeneration.DB.AppDatabaseHelper dbHelper = new com.qprogramming.bookgeneration.DB.AppDatabaseHelper (this);
        AppEnv.db = dbHelper.getWritableDatabase();


//        changeFragment(TabsFragment.newInstance());
//
//        App.getInstance().bus().toObserverable()
//                .subscribeOn(Schedulers.io())
//                .observeOn(AndroidSchedulers.mainThread())
//                .subscribe(obj -> {
//                    Log.d("BUS", "observed event");
//                    if (obj instanceof WorkPlan) {
//                        final WorkPlan workPlan = (WorkPlan) obj;
//                        changeFragment(WorkPlanFragment.newInstance(workPlan));
//                    }
//                });


        //check if require upgrade the app version
        PackageInfo pInfo;
        try {
            pInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
            new GetVerTask().execute(pInfo.versionCode);
        } catch (PackageManager.NameNotFoundException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }


        try
        {
            final Handler handler1 = new Handler();
            handler1.postDelayed(new Runnable() {
                @Override
                public void run() {

//                    if (AppEnv.Personal.getLaundry() == 0)
//                    {
//                        Bundle args = new Bundle();
//                        args.putParcelable("receiverTag", mReceiver);
//                        fragmentRegistration.setArguments(args);
//
//                        getFragmentManager().beginTransaction()
//                                .replace(R.id.container, fragmentRegistration, "myfragment")
//                                .commit();
//                    }
//                    else
//                    {
//                        GetDepartments();
//                        LoadCollectionDates();
//                    }
                }
            }, 2000);
        }
        catch(Exception e)
        {
            Log.e("MainActivity. ", e.getMessage(), e);
        }

        mReceiver = new AppResultReceiver(new Handler());
        mReceiver.setReceiver(this);

    }

    private void changeFragment(final androidx.fragment.app.Fragment fragment) {
        final String simpleName = fragment.getClass().getSimpleName();

        getSupportFragmentManager()
                .beginTransaction()
                .replace(
                        R.id.act_main__container,
                        fragment,
                        simpleName
                )
                .addToBackStack(simpleName)
                .commit();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        this.menu = menu;
        getMenuInflater().inflate(R.menu.menu_main, menu);

        if(item_main_menu == null)
        {
            item_main_menu = menu.findItem(R.id.main_menu);
//            item_main_menu.setVisible(true);
        }
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Bundle args = new Bundle();

        switch (item.getItemId()) {
            case R.id.profile:
                //about("http://109.226.10.249/Facade/Agreement.htm");
                return true;

//            case R.id.working_hours:
//                showPopup(getString(R.string.working_hours), AppEnv.My_Laundry.getHeader());
//                return true;
//            case R.id.curreent_order:
//                if(fragmentLastOrder.getArguments() == null)
//                {
//                    args.putParcelable("receiverTag", mReceiver);
//                    fragmentLastOrder.setArguments(args);
//                }
//                getFragmentManager().beginTransaction()
//                        .addToBackStack("fragmentLastOrder")
//                        .replace(R.id.container, fragmentLastOrder, "fragmentLastOrder")
//                        .commit();
//                return true;
//            case R.id.my_order:
//                fragmentLastOrder = new SelectedOrder();
//                if(fragmentLastOrder.getArguments() == null)
//                {
//                    args.putParcelable("receiverTag", mReceiver);
//                    fragmentLastOrder.setArguments(args);
//                }
//                getFragmentManager().beginTransaction()
//                        .addToBackStack("fragmentLastOrder")
//                        .replace(R.id.container, fragmentLastOrder, "fragmentLastOrder")
//                        .commit();
//                return true;
//            case R.id.private_details:
//                if(fragmentPrivateDetails.getArguments() == null)
//                {
//                    args.putParcelable("receiverTag", mReceiver);
//                    fragmentPrivateDetails.setArguments(args);
//                }
//                getFragmentManager().beginTransaction()
//                        .addToBackStack("fragmentPrivateDetails")
//                        .replace(R.id.container, fragmentPrivateDetails, "fragmentPrivateDetails")
//                        .commit();
//                return true;
//            case R.id.chat:
//                if(fragmentChat.getArguments() == null)
//                {
//                    args.putParcelable("receiverTag", mReceiver);
//                    fragmentChat.setArguments(args);
//                }
//                getFragmentManager().beginTransaction()
//                        .addToBackStack("fragmentChat")
//                        .replace(R.id.container, fragmentChat, "fragmentChat")
//                        .commitAllowingStateLoss();
//                return true;
//            case R.id.complex_order:
//                fragmentComplexOrder = new ComplexOrder();
//                if(fragmentComplexOrder.getArguments() == null)
//                {
//                    args.putParcelable("receiverTag", mReceiver);
//                    fragmentComplexOrder.setArguments(args);
//                }
//                getFragmentManager().beginTransaction()
//                        .addToBackStack("fragmentComplexOrder")
//                        .replace(R.id.container, fragmentComplexOrder, "fragmentComplexOrder")
//                        .commit();
//                return true;
//            case R.id.send_complaint:
//                fragmentComplaint = new Complaint();
//                if(fragmentComplaint.getArguments() == null)
//                {
//                    args.putParcelable("receiverTag", mReceiver);
//                    fragmentComplaint.setArguments(args);
//                }
//
//                getFragmentManager().beginTransaction()
//                        .addToBackStack("fragmentComplaint")
//                        .replace(R.id.container, fragmentComplaint, "fragmentComplaint")
//                        .commit();
//                return true;
//            case R.id.history:
//                if(fragmentHistory.getArguments() == null)
//                {
//                    args.putParcelable("receiverTag", mReceiver);
//                    fragmentHistory.setArguments(args);
//                }
//                getFragmentManager().beginTransaction()
//                        .addToBackStack("fragmentHistory")
//                        .replace(R.id.container, fragmentHistory, "fragmentHistory")
//                        .commit();
//                return true;
//            case R.id.price_list:
//                if(fragmentPricelist.getArguments() == null)
//                {
//                    args.putParcelable("receiverTag", mReceiver);
//                    fragmentPricelist.setArguments(args);
//                }
//                getFragmentManager().beginTransaction()
//                        .addToBackStack("fragmentPricelist")
//                        .replace(R.id.container, fragmentPricelist, "fragmentPricelist")
//                        .commit();
//                return true;

            case R.id.exit:
                final AlertDialog.Builder dlg = new AlertDialog.Builder (activity);

                LayoutInflater inflater = (LayoutInflater)MainActivity.this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                View titleView = inflater.inflate(R.layout.custom_title, null);
                ((TextView) titleView.findViewById(R.id.partName)).setText(getString(R.string.exit));
                //dlg.setCustomTitle(titleView);

                dlg
                        .setCancelable (false)
                        .setPositiveButton(getString(R.string.yes), null)
                        .setNegativeButton (getString(R.string.no), null)
                        .setMessage(R.string.exit_message);
                dialog = dlg.create();
                dialog.show();
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener()
                {
                    @Override
                    public void onClick(View v)
                    {
                        activity.finish();
                        System.exit(0);
                    }
                });
                dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(new View.OnClickListener()
                {
                    @Override
                    public void onClick(View v)
                    {
                        dialog.dismiss();
                    }
                });

                dialog.setOnKeyListener(new DialogInterface.OnKeyListener() {
                    @Override
                    public boolean onKey (DialogInterface dialog, int keyCode, KeyEvent event) {
                        if (keyCode == KeyEvent.KEYCODE_BACK &&
                                !event.isCanceled()) {
                            dialog.cancel();
                            return true;
                        }
                        return false;
                    }
                });
                return true;

            default:
                return super.onOptionsItemSelected(item);

        }
    }


    @Override
    public void update(Observable observable, Object data) {
        try {
            final APdu apdu = (APdu)data;
            if (apdu.type () == APdu.APDU_TYPE.RESPONSE) {
                if (apdu.cmd () == APdu.APDU_CMD.get_message) {
                    Message message = (Message)apdu.response().getData();
                    if(message.getRecordId() > 0)
                    {
                    }
                }

//                else if (apdu.cmd () == APdu.APDU_CMD.upgrade_app_version ) {
//                    final AlertDialog.Builder dlg = new AlertDialog.Builder (activity);
//
//                    LayoutInflater inflater = (LayoutInflater)MainActivity.this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
//                    View titleView = inflater.inflate(R.layout.custom_title, null);
//                    ((TextView) titleView.findViewById(R.id.partName)).setText(getString(R.string.exit));
//                    //dlg.setCustomTitle(titleView);
//
//                    dlg
//                            .setCancelable (false)
//                            .setPositiveButton(getString(R.string.close), null)
//                            .setMessage(R.string.message_upgrade_required);
//                    dialog = dlg.create();
//                    dialog.show();
//                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener()
//                    {
//                        @Override
//                        public void onClick(View v)
//                        {
//                            final String appPackageName = getPackageName(); // getPackageName() from Context or Activity object
//                            try {
//                                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + appPackageName)));
//                            } catch (android.content.ActivityNotFoundException anfe) {
//                                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + appPackageName)));
//                            }
//                            activity.finish();
//                            System.exit(0);
//                        }
//                    });
//                    dialog.setOnKeyListener(new DialogInterface.OnKeyListener() {
//                        @Override
//                        public boolean onKey (DialogInterface dialog, int keyCode, KeyEvent event) {
//                            if (keyCode == KeyEvent.KEYCODE_BACK &&
//                                    !event.isCanceled()) {
//                                final String appPackageName = getPackageName(); // getPackageName() from Context or Activity object
//                                try {
//                                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + appPackageName)));
//                                } catch (android.content.ActivityNotFoundException anfe) {
//                                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + appPackageName)));
//                                }
//                                activity.finish();
//                                System.exit(0);
//                            }
//                            return false;
//                        }
//                    });
//                }

            }
        }
        catch (Exception e) {
            Log.e ("SystemMonitorService", e.getMessage (), e);
        }
    }

    @Override
    public void onBackPressed() {
        if (getFragmentManager().getBackStackEntryCount() > 1 ){
            getFragmentManager().popBackStack();
        } else {
            final AlertDialog.Builder dlg = new AlertDialog.Builder (this);

//            LayoutInflater inflater = (LayoutInflater)MainActivity.this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
//            View titleView = inflater.inflate(R.layout.custom_title, null);
//            ((TextView) titleView.findViewById(R.id.partName)).setText(getString(R.string.exit));
//            //dlg.setCustomTitle(titleView);
//
//            dlg
//                    .setCancelable (false)
//                    .setPositiveButton(getString(R.string.yes), null)
//                    .setNegativeButton (getString(R.string.no), null)
//                    .setMessage(R.string.exit_message);
//            dialog = dlg.create();
//            dialog.show();
//            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener()
//            {
//                @Override
//                public void onClick(View v)
//                {
//                    activity.finish();
//                    System.exit(0);
//                }
//            });
//            dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(new View.OnClickListener()
//            {
//                @Override
//                public void onClick(View v)
//                {
//                    dialog.dismiss();
//                }
//            });
//
//            dialog.setOnKeyListener(new DialogInterface.OnKeyListener() {
//                @Override
//                public boolean onKey (DialogInterface dialog, int keyCode, KeyEvent event) {
//                    if (keyCode == KeyEvent.KEYCODE_BACK &&
//                            !event.isCanceled()) {
//                        dialog.cancel();
//                        return true;
//                    }
//                    return false;
//                }
//            });

        }
    }

    @Override
    public void onReceiveResult(int resultCode, Bundle resultData) {

    }



    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

//        if (id == R.id.nav_profile) {
//            Intent mainIntent = new Intent(MainActivity.this, RegisterActivity.class);
//            startActivity(mainIntent);
//            finish();
//        } else if (id == R.id.nav_profile_new) {
//            Intent mainIntent = new Intent(MainActivity.this, Profile.class);
//            startActivity(mainIntent);
//        } else if (id == R.id.nav_my_workplans) {
//            Intent mainIntent = new Intent(MainActivity.this, MyPlansActivity.class);
//            startActivity(mainIntent);
//        } else if (id == R.id.nav_manage) {
//            Intent intent = new Intent(MainActivity.this, ExerciseActivity.class);
//            startActivity(intent);
//        }
*/
/*
//        else if (id == R.id.nav_scan){
//            FragmentManager manager = getFragmentManager();
//            FragmentTransaction transaction = manager.beginTransaction();
//            transaction.replace(R.id.container,scanningFragment,"YOUR_FRAGMENT_STRING_TAG");
//            //transaction.addToBackStack(null);
//            transaction.commit();
//        }


        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
****************************************************************************************************/
}
