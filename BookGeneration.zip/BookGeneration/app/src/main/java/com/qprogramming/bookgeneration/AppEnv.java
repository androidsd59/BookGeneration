package com.qprogramming.bookgeneration;

import android.database.sqlite.SQLiteDatabase;

import com.qprogramming.bookgeneration.Entities.Customer;
import com.qprogramming.bookgeneration.Util.DiskLruCacheAdapter;

public class AppEnv {
    public static SQLiteDatabase db = null;

    public static Customer Personal = new Customer();
    public static DiskLruCacheAdapter diskAdapter = new DiskLruCacheAdapter();

    static int GymId;

//    public static String host = "http://109.226.10.249/Road/";
//    public static String url = host + "facade.svc";
    // TODO   test request about condition user
    public static String host = "http://109.226.10.249/Road/";
    public static String url = host + "facade.svc/";

}
